const { onDocumentCreated } = require("firebase-functions/v2/firestore");
const { initializeApp } = require("firebase-admin/app");
const { getFirestore } = require("firebase-admin/firestore");
const { getMessaging } = require("firebase-admin/messaging");

initializeApp();

const DATABASE_ID = "ai-studio-android-videoplu-55242e8a-262d-498a-ad56-5de918ffecc0";

exports.onVideoPublished = onDocumentCreated(
  {
    document: "videos/{videoId}",
    database: DATABASE_ID,
  },
  async (event) => {
    const video = event.data?.data();
    if (!video || video.privacy !== "PUBLIC") return;

    const db = getFirestore(DATABASE_ID);
    const authorId = video.authorId;
    const subscribersSnap = await db
      .collectionGroup("subscriptions")
      .where("channelId", "==", authorId)
      .get();

    const tokens = [];
    for (const subDoc of subscribersSnap.docs) {
      const subUserId = subDoc.data().userId;
      if (!subUserId || subUserId === authorId) continue;

      await db
        .collection("users")
        .doc(subUserId)
        .collection("notifications")
        .add({
          userId: subUserId,
          title: video.authorName || "New Video",
          body: video.title || "Uploaded a new video",
          type: "NEW_VIDEO",
          targetVideoId: event.params.videoId,
          readFlag: false,
          createdAt: new Date(),
        });

      const privSnap = await db
        .collection("users")
        .doc(subUserId)
        .collection("private")
        .doc("info")
        .get();
      const fcmToken = privSnap.data()?.fcmToken;
      if (fcmToken) tokens.push(fcmToken);
    }

    if (tokens.length > 0) {
      await getMessaging().sendEachForMulticast({
        tokens,
        notification: {
          title: video.authorName || "Video Plus",
          body: video.title || "New video available",
        },
        data: {
          videoId: event.params.videoId,
        },
      });
    }
  }
);
