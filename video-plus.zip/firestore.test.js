const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_123";
const BOB_UID = "bob_456";
const ADMIN_EMAIL = "adhamdws@gmail.com";

const [emulatorHost, emulatorPortStr] = (process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085").split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

function pastDate(msOffset = 2000) {
  return new Date(Date.now() - msOffset);
}

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("Unauthenticated users cannot read or write any collection", async () => {
  const unauth = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauth.collection("videos").where("privacy", "==", "PUBLIC").where("status", "==", "ACTIVE").get());
  await assertFails(unauth.collection("users").doc(ALICE_UID).get());
  await assertFails(unauth.collection("categories").where("active", "==", true).get());
});

test("Public profile and private PII isolation work as designed", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const now = pastDate(5000);

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).set({
      userId: ALICE_UID,
      displayName: "أليس",
      username: "alice_creator",
      bio: "صانعة محتوى",
      avatarUrl: "https://example.com/a.jpg",
      subscribersCount: 0,
      videosCount: 0,
      banned: false,
      createdAt: now,
      updatedAt: now,
    })
  );

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("private").doc("info").set({
      userId: ALICE_UID,
      email: "alice@example.com",
      languageCode: "ar",
      themeMode: "DARK",
      locationConsent: false,
      blockedUserIds: [],
      createdAt: now,
      updatedAt: now,
    })
  );

  // Bob can read Alice public profile, NOT Alice private PII
  await assertSucceeds(bobDb.collection("users").doc(ALICE_UID).get());
  await assertFails(bobDb.collection("users").doc(ALICE_UID).collection("private").doc("info").get());

  // Alice cannot self-ban or inject ghost fields
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).update({
      banned: true,
      updatedAt: pastDate(1000),
    })
  );
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).update({
      isVerified: true,
      updatedAt: pastDate(1000),
    })
  );
});

test("Video creation, aligned list queries, private video isolation, and votes/comments", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const t = pastDate(5000);

  // Create public video
  await assertSucceeds(
    aliceDb.collection("videos").doc("vid_pub_1").set({
      authorId: ALICE_UID,
      authorName: "Alice",
      title: "تجربة فيديو بلس",
      description: "وصف الفيديو التجريبي",
      category: "tech",
      videoUrl: "https://storage.example.com/v1.mp4",
      thumbnailUrl: "https://storage.example.com/t1.jpg",
      privacy: "PUBLIC",
      shortVideo: false,
      durationSec: 120,
      viewsCount: 0,
      likesCount: 0,
      dislikesCount: 0,
      commentsCount: 0,
      status: "ACTIVE",
      createdAt: t,
      updatedAt: t,
    })
  );

  // Create private video
  await assertSucceeds(
    aliceDb.collection("videos").doc("vid_priv_1").set({
      authorId: ALICE_UID,
      authorName: "Alice",
      title: "فيديو خاص",
      description: "خاص",
      category: "tech",
      videoUrl: "https://storage.example.com/v2.mp4",
      thumbnailUrl: "",
      privacy: "PRIVATE",
      shortVideo: true,
      durationSec: 30,
      viewsCount: 0,
      likesCount: 0,
      dislikesCount: 0,
      commentsCount: 0,
      status: "ACTIVE",
      createdAt: t,
      updatedAt: t,
    })
  );

  // Bob cannot read Alice's PRIVATE video or run unfiltered list query
  await assertFails(bobDb.collection("videos").doc("vid_priv_1").get());
  await assertFails(bobDb.collection("videos").get());

  // Bob CAN run aligned PUBLIC + ACTIVE list query
  await assertSucceeds(
    bobDb.collection("videos").where("privacy", "==", "PUBLIC").where("status", "==", "ACTIVE").get()
  );

  // Bob cannot hijack Alice's video title, but can increment viewsCount by +1
  await assertFails(
    bobDb.collection("videos").doc("vid_pub_1").update({
      title: "Hacked",
      updatedAt: pastDate(1000),
    })
  );
  await assertSucceeds(
    bobDb.collection("videos").doc("vid_pub_1").update({
      viewsCount: 1,
      updatedAt: pastDate(1000),
    })
  );

  // Bob creates vote & comment
  await assertSucceeds(
    bobDb.collection("videos").doc("vid_pub_1").collection("votes").doc(BOB_UID).set({
      userId: BOB_UID,
      videoId: "vid_pub_1",
      voteType: "LIKE",
      createdAt: pastDate(1000),
      updatedAt: pastDate(1000),
    })
  );
  await assertSucceeds(
    bobDb.collection("videos").doc("vid_pub_1").collection("comments").doc("c_1").set({
      videoId: "vid_pub_1",
      authorId: BOB_UID,
      authorName: "Bob",
      text: "فيديو رائع!",
      likesCount: 0,
      createdAt: pastDate(1000),
      updatedAt: pastDate(1000),
    })
  );
});

test("Admin checks enforce email_verified == true and block non-admins", async () => {
  const bobDb = testEnv.authenticatedContext(BOB_UID, { email: "bob@example.com", email_verified: true }).firestore();
  const spoofedAdminDb = testEnv.authenticatedContext("spoof_uid", { email: ADMIN_EMAIL, email_verified: false }).firestore();
  const realAdminDb = testEnv.authenticatedContext("admin_uid", { email: ADMIN_EMAIL, email_verified: true }).firestore();

  const catPayload = {
    nameAr: "تقنية",
    nameEn: "Technology",
    slug: "tech",
    sortOrder: 1,
    active: true,
    createdAt: pastDate(2000),
    updatedAt: pastDate(2000),
  };

  await assertFails(bobDb.collection("categories").doc("tech").set(catPayload));
  await assertFails(spoofedAdminDb.collection("categories").doc("tech").set(catPayload));
  await assertSucceeds(realAdminDb.collection("categories").doc("tech").set(catPayload));
});
