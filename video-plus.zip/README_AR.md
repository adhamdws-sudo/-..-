# دليل تشغيل وبناء تطبيق Video Plus – فيديو بلس

## 1. نظرة عامة
تطبيق **Video Plus – فيديو بلس** هو تطبيق Android مبني بلغة **Kotlin** وواجهة **Jetpack Compose (Material 3)** مع دعم كامل للغة العربية (RTL) والإنجليزية (LTR)، والوضع الليلي والنهاري، ومشغل **Android Media3 ExoPlayer**، وتسجيل الفيديو عبر **CameraX**، وخدمات **Firebase**.

## 2. حالة خدمات Firebase
- تم ربط المشروع بقاعدة بيانات **Cloud Firestore** (القاعدة المسمّاة داخل `app/src/main/res/values/firebase_applet_config.xml`) و**Firebase Authentication (Google Sign-In)** عبر `app/google-services.json`.
- **خطوات إضافية مطلوبة من Firebase Console لتفعيل الخدمات الاختيارية بالكامل**:
  1. افتح مشروع Firebase: `gen-lang-client-0247376986` في [Firebase Console](https://console.firebase.google.com).
  2. من **Storage** اضغط **Get Started** لإنشاء حاوية التخزين، ثم انشر قواعد الأمان من ملف `storage.rules`.
  3. من **App Check** سجّل تطبيق Android باستخدام **Play Integrity** للنسخة النهائية وDebug token للتطوير.
  4. لنشر **Cloud Functions** المسؤولة عن إشعارات FCM عند نشر فيديو جديد، نفّذ داخل مجلد `functions/`:
     ```bash
     npm install firebase-functions firebase-admin
     firebase deploy --only functions,storage
     ```

## 3. تصدير المشروع وبناء ملف APK و ZIP
- **من واجهة AI Studio مباشرة**:
  - يمكنك تصدير المشروع كاملاً كملف **ZIP** أو دفعه إلى **GitHub** أو توليد **APK / AAB** مباشرة من قائمة الإعدادات في أعلى المنصة.
- **من سطر الأوامر (Android Studio / Gradle)**:
  - لتوليد نسخة تجريبية (Debug APK):
    ```bash
    gradle :app:assembleDebug
    ```
    ستجد الملف في: `app/build/outputs/apk/debug/app-debug.apk`.
  - لتوليد نسخة نهائية موقعة (Release APK):
    1. جهّز مفتاح التوقيع (`my-upload-key.jks`) ومتغيرات البيئة `KEYSTORE_PATH` و`STORE_PASSWORD` و`KEY_PASSWORD`.
    2. نفّذ:
       ```bash
       gradle :app:assembleRelease
       ```
       ستجد الملف في: `app/build/outputs/apk/release/app-release.apk`.

## 4. صلاحيات المسؤول (Admin Dashboard)
- لا تُفعَّل صلاحيات المسؤول من الواجهة؛ يتم التحقق منها على الخادم عبر قواعد `firestore.rules` (البريد الموثّق `adhamdws@gmail.com` أو إضافة معرف المستخدم إلى مجموعة `/admins/{uid}` في Firestore).
