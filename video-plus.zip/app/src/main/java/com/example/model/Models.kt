package com.example.model

import androidx.annotation.Keep
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

enum class VideoPrivacy(val raw: String) {
    PUBLIC("PUBLIC"),
    PRIVATE("PRIVATE"),
    UNLISTED("UNLISTED");

    companion object {
        fun fromRaw(raw: String?): VideoPrivacy =
            entries.firstOrNull { it.raw == raw } ?: PUBLIC
    }
}

enum class VoteType(val raw: String) {
    LIKE("LIKE"),
    DISLIKE("DISLIKE");

    companion object {
        fun fromRaw(raw: String?): VoteType? =
            entries.firstOrNull { it.raw == raw }
    }
}

enum class ThemeModePreference(val raw: String) {
    SYSTEM("SYSTEM"),
    LIGHT("LIGHT"),
    DARK("DARK");

    companion object {
        fun fromRaw(raw: String?): ThemeModePreference =
            entries.firstOrNull { it.raw == raw } ?: SYSTEM
    }
}

enum class NotificationType(val raw: String) {
    NEW_VIDEO("NEW_VIDEO"),
    COMMENT("COMMENT"),
    SUBSCRIPTION("SUBSCRIPTION"),
    ADMIN_ANNOUNCEMENT("ADMIN_ANNOUNCEMENT");

    companion object {
        fun fromRaw(raw: String?): NotificationType =
            entries.firstOrNull { it.raw == raw } ?: ADMIN_ANNOUNCEMENT
    }
}

@Keep
@IgnoreExtraProperties
data class PublicProfile(
    @DocumentId val id: String = "",
    val userId: String = "",
    val displayName: String = "",
    val username: String = "",
    val bio: String? = null,
    val avatarUrl: String? = null,
    val subscribersCount: Long = 0L,
    val videosCount: Long = 0L,
    val banned: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null,
)

@Keep
@IgnoreExtraProperties
data class PrivateAccountInfo(
    @DocumentId val id: String = "",
    val userId: String = "",
    val email: String = "",
    val fcmToken: String? = null,
    val languageCode: String = "ar",
    val themeMode: String = ThemeModePreference.SYSTEM.raw,
    val locationConsent: Boolean = false,
    val blockedUserIds: List<String> = emptyList(),
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null,
)

@Keep
@IgnoreExtraProperties
data class VideoItem(
    @DocumentId val id: String = "",
    val authorId: String = "",
    val authorName: String = "",
    val authorAvatarUrl: String? = null,
    val title: String = "",
    val description: String = "",
    val category: String = "general",
    val videoUrl: String = "",
    val thumbnailUrl: String = "",
    val privacy: String = VideoPrivacy.PUBLIC.raw,
    val shortVideo: Boolean = false,
    val durationSec: Long = 0L,
    val viewsCount: Long = 0L,
    val likesCount: Long = 0L,
    val dislikesCount: Long = 0L,
    val commentsCount: Long = 0L,
    val locationLabel: String? = null,
    val qualityLabels: List<String>? = null,
    val status: String = "ACTIVE",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null,
)

@Keep
@IgnoreExtraProperties
data class VideoVote(
    @DocumentId val id: String = "",
    val userId: String = "",
    val videoId: String = "",
    val voteType: String = VoteType.LIKE.raw,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null,
)

@Keep
@IgnoreExtraProperties
data class VideoComment(
    @DocumentId val id: String = "",
    val videoId: String = "",
    val authorId: String = "",
    val authorName: String = "",
    val authorAvatarUrl: String? = null,
    val text: String = "",
    val parentCommentId: String? = null,
    val likesCount: Long = 0L,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null,
)

@Keep
@IgnoreExtraProperties
data class SavedVideoRef(
    @DocumentId val id: String = "",
    val userId: String = "",
    val videoId: String = "",
    val title: String = "",
    val thumbnailUrl: String? = null,
    val authorName: String = "",
    val durationSec: Long = 0L,
    val shortVideo: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null,
)

@Keep
@IgnoreExtraProperties
data class WatchHistoryItem(
    @DocumentId val id: String = "",
    val userId: String = "",
    val videoId: String = "",
    val title: String = "",
    val thumbnailUrl: String? = null,
    val authorName: String = "",
    val durationSec: Long = 0L,
    val watchedPositionMs: Long = 0L,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null,
)

@Keep
@IgnoreExtraProperties
data class Subscription(
    @DocumentId val id: String = "",
    val userId: String = "",
    val channelId: String = "",
    val channelName: String = "",
    val channelAvatarUrl: String? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
)

@Keep
@IgnoreExtraProperties
data class AppNotification(
    @DocumentId val id: String = "",
    val userId: String = "",
    val title: String = "",
    val body: String = "",
    val type: String = NotificationType.ADMIN_ANNOUNCEMENT.raw,
    val targetVideoId: String? = null,
    val readFlag: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null,
)

@Keep
@IgnoreExtraProperties
data class VideoCategory(
    @DocumentId val id: String = "",
    val nameAr: String = "",
    val nameEn: String = "",
    val slug: String = "",
    val sortOrder: Long = 0L,
    val active: Boolean = true,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null,
)

@Keep
@IgnoreExtraProperties
data class VideoReport(
    @DocumentId val id: String = "",
    val reporterId: String = "",
    val videoId: String = "",
    val videoTitle: String = "",
    val targetUserId: String = "",
    val reason: String = "",
    val details: String? = null,
    val status: String = "PENDING",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null,
)

@Keep
@IgnoreExtraProperties
data class AdminAnnouncement(
    @DocumentId val id: String = "",
    val authorId: String = "",
    val title: String = "",
    val message: String = "",
    val active: Boolean = true,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null,
)

@Keep
@IgnoreExtraProperties
data class AppCloudConfig(
    @DocumentId val id: String = "",
    val latestVersionCode: Long = 1L,
    val latestVersionName: String = "1.0",
    val updateNotesAr: String = "",
    val updateNotesEn: String = "",
    val downloadUrl: String = "",
    val forceUpdate: Boolean = false,
    @ServerTimestamp val updatedAt: Timestamp? = null,
)

sealed interface UiState<out T> {
    data object Loading : UiState<Nothing>
    data class Success<T>(val data: T) : UiState<T>
    data class Error(val message: String) : UiState<Nothing>
}
