package com.example.ui.home

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SystemUpdate
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.BuildConfig
import com.example.model.AdminAnnouncement
import com.example.model.AppCloudConfig
import com.example.model.UiState
import com.example.model.VideoCategory
import com.example.model.VideoItem
import com.example.ui.FeedFilterMode
import com.example.ui.components.EmptyVideosIllustration
import com.example.ui.components.ShortPreviewCard
import com.example.ui.components.VideoFeedCard
import com.example.ui.i18n.LocalAppStrings

@Composable
fun HomeScreen(
    videosState: UiState<List<VideoItem>>,
    categories: List<VideoCategory>,
    announcements: List<AdminAnnouncement>,
    cloudConfig: AppCloudConfig?,
    searchQuery: String,
    selectedCategory: String,
    feedMode: FeedFilterMode,
    blockedUserIds: Set<String>,
    unreadNotificationsCount: Int,
    hasMorePages: Boolean,
    onSearchChange: (String) -> Unit,
    onCategorySelected: (String) -> Unit,
    onFeedModeSelected: (FeedFilterMode) -> Unit,
    onLoadMore: () -> Unit,
    onVideoClick: (String) -> Unit,
    onShortClick: (String) -> Unit,
    onChannelClick: (String) -> Unit,
    onNotificationsClick: () -> Unit,
) {
    val strings = LocalAppStrings.current
    val context = LocalContext.current
    var searchExpanded by remember { mutableStateOf(false) }

    val defaultCategories = remember(strings.isArabic) {
        listOf(
            VideoCategory(id = "tech", nameAr = "تقنية", nameEn = "Tech", slug = "tech", sortOrder = 1),
            VideoCategory(id = "gaming", nameAr = "ألعاب", nameEn = "Gaming", slug = "gaming", sortOrder = 2),
            VideoCategory(id = "education", nameAr = "تعليم", nameEn = "Education", slug = "education", sortOrder = 3),
            VideoCategory(id = "sports", nameAr = "رياضة", nameEn = "Sports", slug = "sports", sortOrder = 4),
            VideoCategory(id = "general", nameAr = "منوعات", nameEn = "General", slug = "general", sortOrder = 5),
        )
    }
    val effectiveCategories = remember(categories, defaultCategories) {
        if (categories.isNotEmpty()) categories else defaultCategories
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Top Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    shape = CircleShape,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(34.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onPrimary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = strings.appName,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = { searchExpanded = !searchExpanded },
                    modifier = Modifier.testTag("home_search_toggle")
                ) {
                    Icon(
                        imageVector = if (searchExpanded) Icons.Default.Close else Icons.Default.Search,
                        contentDescription = strings.searchHint
                    )
                }
                IconButton(
                    onClick = onNotificationsClick,
                    modifier = Modifier.testTag("home_notifications_button")
                ) {
                    BadgedBox(
                        badge = {
                            if (unreadNotificationsCount > 0) {
                                Badge { Text(unreadNotificationsCount.coerceAtMost(99).toString()) }
                            }
                        }
                    ) {
                        Icon(
                            imageVector = Icons.Default.Notifications,
                            contentDescription = strings.notifications
                        )
                    }
                }
            }
        }

        if (searchExpanded) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = onSearchChange,
                placeholder = { Text(strings.searchHint) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { onSearchChange("") }) {
                            Icon(Icons.Default.Close, contentDescription = null)
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp)
                    .testTag("home_search_input")
            )
        }

        // Category Chips
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item {
                FilterChip(
                    selected = selectedCategory == "all",
                    onClick = { onCategorySelected("all") },
                    label = { Text(strings.allCategories) },
                    modifier = Modifier.testTag("cat_chip_all")
                )
            }
            items(effectiveCategories, key = { it.slug }) { cat ->
                FilterChip(
                    selected = selectedCategory == cat.slug,
                    onClick = { onCategorySelected(cat.slug) },
                    label = { Text(if (strings.isArabic) cat.nameAr else cat.nameEn) },
                    modifier = Modifier.testTag("cat_chip_${cat.slug}")
                )
            }
        }

        // Feed Sorting Mode Chips (Latest / Most Viewed / Recommended)
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item {
                FilterChip(
                    selected = feedMode == FeedFilterMode.LATEST,
                    onClick = { onFeedModeSelected(FeedFilterMode.LATEST) },
                    label = { Text(strings.feedLatest) },
                    modifier = Modifier.testTag("feed_mode_latest")
                )
            }
            item {
                FilterChip(
                    selected = feedMode == FeedFilterMode.MOST_VIEWED,
                    onClick = { onFeedModeSelected(FeedFilterMode.MOST_VIEWED) },
                    label = { Text(strings.feedMostViewed) },
                    modifier = Modifier.testTag("feed_mode_most_viewed")
                )
            }
            item {
                FilterChip(
                    selected = feedMode == FeedFilterMode.RECOMMENDED,
                    onClick = { onFeedModeSelected(FeedFilterMode.RECOMMENDED) },
                    label = { Text(strings.feedRecommended) },
                    modifier = Modifier.testTag("feed_mode_recommended")
                )
            }
        }

        when (videosState) {
            is UiState.Loading -> {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
            }
            is UiState.Error -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = videosState.message,
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodyLarge
                    )
                }
            }
            is UiState.Success -> {
                val filtered = remember(videosState.data, blockedUserIds, selectedCategory, searchQuery, feedMode) {
                    val q = searchQuery.trim().lowercase()
                    val base = videosState.data.filter { v ->
                        v.authorId !in blockedUserIds &&
                            (selectedCategory == "all" || v.category == selectedCategory) &&
                            (q.isEmpty() || v.title.lowercase().contains(q) || v.authorName.lowercase().contains(q) || v.description.lowercase().contains(q))
                    }
                    when (feedMode) {
                        FeedFilterMode.LATEST -> base.sortedByDescending { it.createdAt?.seconds ?: 0L }
                        FeedFilterMode.MOST_VIEWED -> base.sortedByDescending { it.viewsCount }
                        FeedFilterMode.RECOMMENDED -> base.sortedByDescending { (it.likesCount * 3L) + it.viewsCount + (it.commentsCount * 2L) }
                    }
                }
                val shortsList = remember(filtered) { filtered.filter { it.shortVideo } }
                val standardList = remember(filtered) { filtered.filter { !it.shortVideo } }

                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Cloud APK Update Banner
                    if (cloudConfig != null && cloudConfig.latestVersionCode > BuildConfig.VERSION_CODE) {
                        item(key = "cloud_update_banner") {
                            Card(
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                                shape = RoundedCornerShape(16.dp)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.SystemUpdate,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.onPrimaryContainer
                                    )
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = "${strings.updateAvailableTitle} (${cloudConfig.latestVersionName})",
                                            style = MaterialTheme.typography.titleSmall,
                                            color = MaterialTheme.colorScheme.onPrimaryContainer
                                        )
                                        val notes = if (strings.isArabic) cloudConfig.updateNotesAr else cloudConfig.updateNotesEn
                                        if (notes.isNotBlank()) {
                                            Text(
                                                text = notes,
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onPrimaryContainer
                                            )
                                        }
                                    }
                                    Button(
                                        onClick = {
                                            val uri = Uri.parse(cloudConfig.downloadUrl)
                                            context.startActivity(Intent(Intent.ACTION_VIEW, uri))
                                        }
                                    ) {
                                        Text(strings.updateNow)
                                    }
                                }
                            }
                        }
                    }

                    // Active Admin Announcement Banner
                    announcements.firstOrNull()?.let { ann ->
                        item(key = "announcement_${ann.id}") {
                            Card(
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
                                shape = RoundedCornerShape(16.dp)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Campaign,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.onSecondaryContainer
                                    )
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = ann.title,
                                            style = MaterialTheme.typography.titleSmall,
                                            color = MaterialTheme.colorScheme.onSecondaryContainer
                                        )
                                        Text(
                                            text = ann.message,
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = MaterialTheme.colorScheme.onSecondaryContainer
                                        )
                                    }
                                }
                            }
                        }
                    }

                    if (shortsList.isNotEmpty()) {
                        item(key = "shorts_shelf") {
                            Column {
                                Text(
                                    text = strings.shortsShelf,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = MaterialTheme.colorScheme.onBackground,
                                    modifier = Modifier.padding(bottom = 10.dp)
                                )
                                LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                    items(shortsList, key = { it.id }) { shortItem ->
                                        ShortPreviewCard(
                                            video = shortItem,
                                            onClick = { onShortClick(shortItem.id) }
                                        )
                                    }
                                }
                            }
                        }
                    }

                    if (standardList.isEmpty() && shortsList.isEmpty()) {
                        item(key = "empty_feed") {
                            EmptyVideosIllustration(
                                title = strings.emptyVideosTitle,
                                body = strings.emptyVideosBody
                            )
                        }
                    } else {
                        items(standardList, key = { it.id }) { video ->
                            VideoFeedCard(
                                video = video,
                                onClick = { onVideoClick(video.id) },
                                onChannelClick = { onChannelClick(video.authorId) }
                            )
                        }
                        if (hasMorePages && filtered.isNotEmpty()) {
                            item(key = "load_more_btn") {
                                OutlinedButton(
                                    onClick = onLoadMore,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("home_load_more_button")
                                ) {
                                    Text(strings.loadMore)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
