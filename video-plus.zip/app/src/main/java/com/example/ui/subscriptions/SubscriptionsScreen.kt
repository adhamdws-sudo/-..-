package com.example.ui.subscriptions

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.model.Subscription
import com.example.model.VideoItem
import com.example.ui.components.AvatarCircle
import com.example.ui.components.EmptyVideosIllustration
import com.example.ui.components.VideoFeedCard
import com.example.ui.i18n.LocalAppStrings

@Composable
fun SubscriptionsScreen(
    subscriptions: List<Subscription>,
    allVideos: List<VideoItem>,
    onVideoClick: (String) -> Unit,
    onChannelClick: (String) -> Unit,
) {
    val strings = LocalAppStrings.current
    val subIds = remember(subscriptions) { subscriptions.map { it.channelId }.toSet() }
    val feed = remember(allVideos, subIds) {
        allVideos.filter { it.authorId in subIds }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        Text(
            text = strings.navSubscriptions,
            style = MaterialTheme.typography.headlineSmall,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 14.dp)
        )

        if (subscriptions.isEmpty()) {
            EmptyVideosIllustration(
                title = strings.navSubscriptions,
                body = strings.noSubscriptionsYet
            )
            return
        }

        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            items(subscriptions, key = { it.channelId }) { sub ->
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .width(72.dp)
                        .clickable { onChannelClick(sub.channelId) }
                ) {
                    AvatarCircle(sub.channelName, sub.channelAvatarUrl, sizeDp = 56)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = sub.channelName,
                        style = MaterialTheme.typography.labelSmall,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            items(feed, key = { it.id }) { video ->
                VideoFeedCard(
                    video = video,
                    onClick = { onVideoClick(video.id) },
                    onChannelClick = { onChannelClick(video.authorId) }
                )
            }
        }
    }
}
