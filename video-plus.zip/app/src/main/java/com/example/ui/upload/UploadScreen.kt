package com.example.ui.upload

import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.location.Geocoder
import android.media.MediaMetadataRetriever
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import coil.compose.AsyncImage
import com.example.data.UploadProgressState
import com.example.model.VideoCategory
import com.example.model.VideoPrivacy
import com.example.ui.components.formatDuration
import com.example.ui.i18n.LocalAppStrings
import com.google.android.gms.location.LocationServices
import java.util.Locale

@Composable
fun UploadScreen(
    recordedVideoUri: Uri?,
    categories: List<VideoCategory>,
    uploadState: UploadProgressState,
    locationConsentGranted: Boolean,
    onGrantLocationConsent: (Boolean) -> Unit,
    onOpenCameraRecorder: () -> Unit,
    onPublish: (
        videoUri: Uri,
        thumbnailUri: Uri?,
        title: String,
        description: String,
        category: String,
        privacy: VideoPrivacy,
        shortVideo: Boolean,
        durationSec: Long,
        locationLabel: String?,
    ) -> Unit,
    onCancelUpload: () -> Unit,
    onResetUploadState: () -> Unit,
    onWatchPublished: (String) -> Unit,
) {
    val strings = LocalAppStrings.current
    val context = LocalContext.current

    var selectedVideoUri by remember { mutableStateOf<Uri?>(null) }
    var selectedThumbnailUri by remember { mutableStateOf<Uri?>(null) }
    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("general") }
    var privacy by remember { mutableStateOf(VideoPrivacy.PUBLIC) }
    var isShortVideo by remember { mutableStateOf(false) }
    var detectedDurationSec by remember { mutableLongStateOf(0L) }
    var attachLocation by remember { mutableStateOf(false) }
    var locationLabel by remember { mutableStateOf<String?>(null) }
    var showLocationConsentDialog by remember { mutableStateOf(false) }

    LaunchedEffect(recordedVideoUri) {
        if (recordedVideoUri != null) {
            selectedVideoUri = recordedVideoUri
        }
    }

    LaunchedEffect(selectedVideoUri) {
        val uri = selectedVideoUri ?: return@LaunchedEffect
        try {
            val retriever = MediaMetadataRetriever()
            retriever.setDataSource(context, uri)
            val durMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            retriever.release()
            detectedDurationSec = (durMs / 1000L).coerceAtLeast(1L)
            if (detectedDurationSec in 1L..60L) {
                isShortVideo = true
            }
        } catch (_: Exception) {
            detectedDurationSec = 0L
        }
    }

    val videoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia(),
        onResult = { uri -> if (uri != null) selectedVideoUri = uri }
    )

    val thumbnailPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia(),
        onResult = { uri -> if (uri != null) selectedThumbnailUri = uri }
    )

    @SuppressLint("MissingPermission")
    fun fetchCoarseLocation() {
        val client = LocationServices.getFusedLocationProviderClient(context)
        client.lastLocation.addOnSuccessListener { loc ->
            if (loc != null) {
                try {
                    val geocoder = Geocoder(context, Locale.getDefault())
                    @Suppress("DEPRECATION")
                    val addresses = geocoder.getFromLocation(loc.latitude, loc.longitude, 1)
                    val addr = addresses?.firstOrNull()
                    locationLabel = listOfNotNull(addr?.locality, addr?.countryName)
                        .joinToString(", ")
                        .ifBlank { "${String.format(Locale.US, "%.2f", loc.latitude)}, ${String.format(Locale.US, "%.2f", loc.longitude)}" }
                } catch (_: Exception) {
                    locationLabel = "${String.format(Locale.US, "%.2f", loc.latitude)}, ${String.format(Locale.US, "%.2f", loc.longitude)}"
                }
            }
        }
    }

    val locationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission(),
        onResult = { granted ->
            if (granted) {
                attachLocation = true
                fetchCoarseLocation()
            } else {
                attachLocation = false
            }
        }
    )

    val defaultCategories = remember(strings.isArabic) {
        listOf(
            VideoCategory(id = "tech", nameAr = "تقنية", nameEn = "Tech", slug = "tech"),
            VideoCategory(id = "gaming", nameAr = "ألعاب", nameEn = "Gaming", slug = "gaming"),
            VideoCategory(id = "education", nameAr = "تعليم", nameEn = "Education", slug = "education"),
            VideoCategory(id = "sports", nameAr = "رياضة", nameEn = "Sports", slug = "sports"),
            VideoCategory(id = "general", nameAr = "منوعات", nameEn = "General", slug = "general"),
        )
    }
    val effectiveCategories = if (categories.isNotEmpty()) categories else defaultCategories

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text(
            text = strings.uploadTitle,
            style = MaterialTheme.typography.headlineSmall,
            color = MaterialTheme.colorScheme.onBackground
        )

        // Source Buttons: Zero-Permission Photo Picker & CameraX Recorder
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            OutlinedButton(
                onClick = {
                    videoPickerLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly))
                },
                modifier = Modifier
                    .weight(1f)
                    .testTag("upload_pick_video_button")
            ) {
                Icon(Icons.Default.VideoLibrary, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(strings.pickVideoFromDevice, maxLines = 1)
            }
            OutlinedButton(
                onClick = onOpenCameraRecorder,
                modifier = Modifier
                    .weight(1f)
                    .testTag("upload_record_video_button")
            ) {
                Icon(Icons.Default.Videocam, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(strings.recordVideoCamera, maxLines = 1)
            }
        }

        if (selectedVideoUri != null) {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(14.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "${selectedVideoUri?.lastPathSegment ?: "video.mp4"} • ${formatDuration(detectedDurationSec)}",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    TextButton(onClick = { selectedVideoUri = null }) {
                        Text(strings.cancel)
                    }
                }
            }
        }

        // Thumbnail picker
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedButton(
                onClick = {
                    thumbnailPickerLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                },
                modifier = Modifier.testTag("upload_pick_thumbnail_button")
            ) {
                Icon(Icons.Default.Image, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(strings.pickThumbnail)
            }
            if (selectedThumbnailUri != null) {
                AsyncImage(
                    model = selectedThumbnailUri,
                    contentDescription = strings.pickThumbnail,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .size(width = 88.dp, height = 50.dp)
                        .clip(RoundedCornerShape(10.dp))
                )
            }
        }

        OutlinedTextField(
            value = title,
            onValueChange = { title = it },
            label = { Text(strings.videoTitleLabel) },
            singleLine = true,
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("upload_title_input")
        )

        OutlinedTextField(
            value = description,
            onValueChange = { description = it },
            label = { Text(strings.videoDescLabel) },
            minLines = 3,
            maxLines = 5,
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("upload_description_input")
        )

        Text(strings.categoryLabel, style = MaterialTheme.typography.titleSmall)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(effectiveCategories, key = { it.slug }) { cat ->
                FilterChip(
                    selected = selectedCategory == cat.slug,
                    onClick = { selectedCategory = cat.slug },
                    label = { Text(if (strings.isArabic) cat.nameAr else cat.nameEn) }
                )
            }
        }

        Text(strings.privacyLabel, style = MaterialTheme.typography.titleSmall)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(
                selected = privacy == VideoPrivacy.PUBLIC,
                onClick = { privacy = VideoPrivacy.PUBLIC },
                label = { Text(strings.privacyPublic) }
            )
            FilterChip(
                selected = privacy == VideoPrivacy.UNLISTED,
                onClick = { privacy = VideoPrivacy.UNLISTED },
                label = { Text(strings.privacyUnlisted) }
            )
            FilterChip(
                selected = privacy == VideoPrivacy.PRIVATE,
                onClick = { privacy = VideoPrivacy.PRIVATE },
                label = { Text(strings.privacyPrivate) }
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(strings.markAsShort, style = MaterialTheme.typography.bodyLarge)
            Switch(
                checked = isShortVideo,
                onCheckedChange = { isShortVideo = it },
                modifier = Modifier.testTag("upload_short_switch")
            )
        }

        // Optional Coarse Location with Explicit Consent
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.LocationOn, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(strings.attachLocationOptional, style = MaterialTheme.typography.bodyLarge)
                }
                if (!locationLabel.isNullOrBlank() && attachLocation) {
                    Text(
                        text = locationLabel ?: "",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.secondary
                    )
                }
            }
            Switch(
                checked = attachLocation,
                onCheckedChange = { checked ->
                    if (!checked) {
                        attachLocation = false
                        locationLabel = null
                    } else if (!locationConsentGranted) {
                        showLocationConsentDialog = true
                    } else {
                        val hasPerm = ContextCompat.checkSelfPermission(
                            context,
                            Manifest.permission.ACCESS_COARSE_LOCATION
                        ) == PackageManager.PERMISSION_GRANTED
                        if (hasPerm) {
                            attachLocation = true
                            fetchCoarseLocation()
                        } else {
                            locationPermissionLauncher.launch(Manifest.permission.ACCESS_COARSE_LOCATION)
                        }
                    }
                },
                modifier = Modifier.testTag("upload_location_switch")
            )
        }

        // Upload Progress / Error / Success Card
        if (uploadState.isUploading) {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "${strings.uploadingProgress} ${(uploadState.progressFraction * 100).toInt()}%",
                        style = MaterialTheme.typography.titleSmall
                    )
                    LinearProgressIndicator(
                        progress = { uploadState.progressFraction },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedButton(
                        onClick = onCancelUpload,
                        modifier = Modifier.testTag("upload_cancel_button")
                    ) {
                        Text(strings.cancelUpload)
                    }
                }
            }
        } else if (!uploadState.errorMessage.isNullOrBlank()) {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                shape = RoundedCornerShape(14.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(uploadState.errorMessage, color = MaterialTheme.colorScheme.onErrorContainer)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = strings.storageSetupHint,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onErrorContainer
                    )
                }
            }
        } else if (!uploadState.publishedVideoId.isNullOrBlank()) {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = strings.watchPublishedVideo,
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                    Button(
                        onClick = {
                            val vid = uploadState.publishedVideoId
                            onResetUploadState()
                            onWatchPublished(vid)
                        },
                        modifier = Modifier.testTag("upload_watch_published_button")
                    ) {
                        Text(strings.watchPublishedVideo)
                    }
                }
            }
        }

        Button(
            onClick = {
                val uri = selectedVideoUri ?: return@Button
                if (title.trim().length < 2) return@Button
                onPublish(
                    uri,
                    selectedThumbnailUri,
                    title,
                    description,
                    selectedCategory,
                    privacy,
                    isShortVideo,
                    detectedDurationSec,
                    if (attachLocation) locationLabel else null,
                )
            },
            enabled = !uploadState.isUploading && selectedVideoUri != null && title.trim().length >= 2,
            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(54.dp)
                .testTag("upload_publish_button")
        ) {
            Icon(Icons.Default.CloudUpload, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text(strings.publishVideo, style = MaterialTheme.typography.labelLarge)
        }
    }

    if (showLocationConsentDialog) {
        AlertDialog(
            onDismissRequest = { showLocationConsentDialog = false },
            title = { Text(strings.locationConsentTitle) },
            text = { Text(strings.locationConsentBody) },
            confirmButton = {
                Button(onClick = {
                    showLocationConsentDialog = false
                    onGrantLocationConsent(true)
                    locationPermissionLauncher.launch(Manifest.permission.ACCESS_COARSE_LOCATION)
                }) { Text(strings.confirm) }
            },
            dismissButton = {
                TextButton(onClick = { showLocationConsentDialog = false }) { Text(strings.cancel) }
            }
        )
    }
}
