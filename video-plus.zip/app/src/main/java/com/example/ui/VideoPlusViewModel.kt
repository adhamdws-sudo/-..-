package com.example.ui

import android.content.Context
import android.net.Uri
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.UploadProgressState
import com.example.data.UserPreferences
import com.example.data.VideoPlusRepository
import com.example.data.PreferencesRepository
import com.example.model.AdminAnnouncement
import com.example.model.AppCloudConfig
import com.example.model.AppNotification
import com.example.model.PrivateAccountInfo
import com.example.model.PublicProfile
import com.example.model.SavedVideoRef
import com.example.model.Subscription
import com.example.model.ThemeModePreference
import com.example.model.UiState
import com.example.model.VideoCategory
import com.example.model.VideoComment
import com.example.model.VideoItem
import com.example.model.VideoPrivacy
import com.example.model.VideoReport
import com.example.model.VoteType
import com.example.model.WatchHistoryItem
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.storage.UploadTask
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class FeedFilterMode {
    LATEST,
    MOST_VIEWED,
    RECOMMENDED,
}

@OptIn(ExperimentalCoroutinesApi::class)
class VideoPlusViewModel(
    private val repository: VideoPlusRepository,
    private val preferencesRepository: PreferencesRepository,
    val currentUserId: String,
) : ViewModel() {

    private val _isAdmin = MutableStateFlow(false)
    val isAdmin: StateFlow<Boolean> = _isAdmin.asStateFlow()

    private val _snackbarMessage = MutableStateFlow<String?>(null)
    val snackbarMessage: StateFlow<String?> = _snackbarMessage.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedCategory = MutableStateFlow("all")
    val selectedCategory: StateFlow<String> = _selectedCategory.asStateFlow()

    private val _feedMode = MutableStateFlow(FeedFilterMode.LATEST)
    val feedMode: StateFlow<FeedFilterMode> = _feedMode.asStateFlow()

    private val _pagedVideos = MutableStateFlow<List<VideoItem>>(emptyList())
    private var lastPageCursor: DocumentSnapshot? = null
    private val _hasMorePages = MutableStateFlow(true)
    val hasMorePages: StateFlow<Boolean> = _hasMorePages.asStateFlow()

    private val _uploadState = MutableStateFlow(UploadProgressState())
    val uploadState: StateFlow<UploadProgressState> = _uploadState.asStateFlow()
    private var activeUploadTask: UploadTask? = null

    private val _selectedVideoId = MutableStateFlow<String?>(null)
    private val _selectedChannelId = MutableStateFlow<String?>(null)

    val preferences: StateFlow<UserPreferences> = preferencesRepository.preferencesFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), UserPreferences())

    val currentUserProfile: StateFlow<PublicProfile?> = repository.observePublicProfile(currentUserId)
        .catch { unwrapOrRethrow(it, "observePublicProfile") }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), null)

    val privateAccount: StateFlow<PrivateAccountInfo?> = repository.observePrivateAccount(currentUserId)
        .catch { unwrapOrRethrow(it, "observePrivateAccount") }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), null)

    val publicVideosState: StateFlow<UiState<List<VideoItem>>> = repository.observePublicVideos(30L)
        .combine(_pagedVideos) { live, paged ->
            (live + paged).distinctBy { it.id }
        }
        .map<List<VideoItem>, UiState<List<VideoItem>>> { UiState.Success(it) }
        .catch { error ->
            val root = extractRootFirestoreError(error)
            Log.w(TAG, "Error observing videos", root)
            emit(UiState.Error(root.message ?: "Failed to load videos"))
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), UiState.Loading)

    val myVideos: StateFlow<List<VideoItem>> = repository.observeMyVideos(currentUserId)
        .catch { unwrapOrRethrow(it, "observeMyVideos") }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), emptyList())

    val savedVideos: StateFlow<List<SavedVideoRef>> = repository.observeSavedVideos(currentUserId)
        .catch { unwrapOrRethrow(it, "observeSavedVideos") }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), emptyList())

    val watchHistory: StateFlow<List<WatchHistoryItem>> = repository.observeWatchHistory(currentUserId)
        .catch { unwrapOrRethrow(it, "observeWatchHistory") }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), emptyList())

    val subscriptions: StateFlow<List<Subscription>> = repository.observeSubscriptions(currentUserId)
        .catch { unwrapOrRethrow(it, "observeSubscriptions") }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), emptyList())

    val notifications: StateFlow<List<AppNotification>> = repository.observeNotifications(currentUserId)
        .catch { unwrapOrRethrow(it, "observeNotifications") }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), emptyList())

    val categories: StateFlow<List<VideoCategory>> = repository.observeCategories()
        .catch { unwrapOrRethrow(it, "observeCategories") }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), emptyList())

    val announcements: StateFlow<List<AdminAnnouncement>> = repository.observeAnnouncements()
        .catch { unwrapOrRethrow(it, "observeAnnouncements") }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), emptyList())

    val cloudConfig: StateFlow<AppCloudConfig?> = repository.observeCloudConfig()
        .catch { unwrapOrRethrow(it, "observeCloudConfig") }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), null)

    // Watch-screen reactive flows
    val activeVideo: StateFlow<VideoItem?> = _selectedVideoId.flatMapLatest { vid ->
        if (vid.isNullOrBlank()) flowOf(null) else repository.observeVideo(vid)
    }.catch { unwrapOrRethrow(it, "observeVideo") }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), null)

    val activeVideoVote: StateFlow<VoteType?> = _selectedVideoId.flatMapLatest { vid ->
        if (vid.isNullOrBlank()) flowOf(null) else repository.observeUserVote(vid, currentUserId)
    }.catch { unwrapOrRethrow(it, "observeUserVote") }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), null)

    val activeVideoComments: StateFlow<List<VideoComment>> = _selectedVideoId.flatMapLatest { vid ->
        if (vid.isNullOrBlank()) flowOf(emptyList()) else repository.observeComments(vid)
    }.catch { unwrapOrRethrow(it, "observeComments") }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), emptyList())

    val viewedChannelProfile: StateFlow<PublicProfile?> = _selectedChannelId.flatMapLatest { cid ->
        if (cid.isNullOrBlank()) flowOf(null) else repository.observePublicProfile(cid)
    }.catch { unwrapOrRethrow(it, "observeChannelProfile") }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), null)

    // Admin reactive streams (only attached when isAdmin == true!)
    val adminReports: StateFlow<List<VideoReport>> = _isAdmin.flatMapLatest { admin ->
        if (!admin) flowOf(emptyList()) else repository.observeAllReportsForAdmin()
    }.catch { unwrapOrRethrow(it, "observeAllReportsForAdmin") }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), emptyList())

    val adminUsers: StateFlow<List<PublicProfile>> = _isAdmin.flatMapLatest { admin ->
        if (!admin) flowOf(emptyList()) else repository.observeAllUsersForAdmin()
    }.catch { unwrapOrRethrow(it, "observeAllUsersForAdmin") }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), emptyList())

    init {
        viewModelScope.launch {
            repository.ensureUserProfileInitialized()
            _isAdmin.value = repository.checkIsAdmin()
        }
    }

    fun clearSnackbar() {
        _snackbarMessage.value = null
    }

    fun postMessage(msg: String) {
        _snackbarMessage.value = msg
    }

    fun updateSearchQuery(q: String) {
        _searchQuery.value = q
    }

    fun selectCategory(slug: String) {
        _selectedCategory.value = slug
    }

    fun selectFeedMode(mode: FeedFilterMode) {
        _feedMode.value = mode
    }

    fun openVideo(videoId: String) {
        _selectedVideoId.value = videoId
    }

    fun openChannel(channelId: String) {
        _selectedChannelId.value = channelId
    }

    fun loadMoreVideos() {
        viewModelScope.launch {
            repository.fetchPublicVideosPage(lastPageCursor, pageSize = 15L)
                .onSuccess { page ->
                    lastPageCursor = page.lastSnapshot
                    _hasMorePages.value = page.hasMore
                    _pagedVideos.value = (_pagedVideos.value + page.videos).distinctBy { it.id }
                }
                .onFailure { _snackbarMessage.value = it.localizedMessage }
        }
    }

    fun recordVideoView(video: VideoItem, positionMs: Long = 0L) {
        viewModelScope.launch {
            repository.recordViewAndHistory(video, positionMs)
        }
    }

    fun toggleVote(videoId: String, voteType: VoteType) {
        viewModelScope.launch {
            repository.toggleVote(videoId, voteType)
                .onFailure { _snackbarMessage.value = it.localizedMessage }
        }
    }

    fun addComment(video: VideoItem, text: String, parentCommentId: String? = null) {
        viewModelScope.launch {
            repository.addComment(video, text, parentCommentId)
                .onFailure { _snackbarMessage.value = it.localizedMessage }
        }
    }

    fun toggleSave(video: VideoItem, currentlySaved: Boolean) {
        viewModelScope.launch {
            repository.toggleSaveVideo(video, currentlySaved)
                .onFailure { _snackbarMessage.value = it.localizedMessage }
        }
    }

    fun toggleSubscription(channelId: String, channelName: String, channelAvatarUrl: String?, subscribed: Boolean) {
        viewModelScope.launch {
            repository.toggleSubscription(channelId, channelName, channelAvatarUrl, subscribed)
                .onFailure { _snackbarMessage.value = it.localizedMessage }
        }
    }

    fun toggleBlockUser(targetUserId: String, block: Boolean) {
        viewModelScope.launch {
            repository.toggleBlockUser(targetUserId, block)
                .onFailure { _snackbarMessage.value = it.localizedMessage }
        }
    }

    fun reportVideo(video: VideoItem, reason: String, details: String?) {
        viewModelScope.launch {
            repository.reportVideo(video, reason, details)
                .onSuccess { _snackbarMessage.value = "Report submitted" }
                .onFailure { _snackbarMessage.value = it.localizedMessage }
        }
    }

    fun markNotificationRead(notificationId: String) {
        viewModelScope.launch {
            repository.markNotificationRead(notificationId)
        }
    }

    fun uploadVideo(
        context: Context,
        videoUri: Uri,
        thumbnailUri: Uri?,
        title: String,
        description: String,
        category: String,
        privacy: VideoPrivacy,
        shortVideo: Boolean,
        durationSec: Long,
        locationLabel: String?,
    ) {
        if (_uploadState.value.isUploading) return
        _uploadState.value = UploadProgressState(isUploading = true, progressFraction = 0.02f)
        viewModelScope.launch {
            val result = repository.uploadAndPublishVideo(
                context = context,
                videoUri = videoUri,
                thumbnailUri = thumbnailUri,
                title = title,
                description = description,
                category = category,
                privacy = privacy,
                shortVideo = shortVideo,
                durationSec = durationSec,
                locationLabel = locationLabel,
                onProgress = { fraction ->
                    _uploadState.value = _uploadState.value.copy(progressFraction = fraction)
                },
                onTaskCreated = { task ->
                    activeUploadTask = task
                }
            )
            activeUploadTask = null
            result.onSuccess { videoId ->
                _uploadState.value = UploadProgressState(
                    isUploading = false,
                    progressFraction = 1f,
                    publishedVideoId = videoId,
                )
            }.onFailure { err ->
                _uploadState.value = UploadProgressState(
                    isUploading = false,
                    progressFraction = 0f,
                    errorMessage = err.localizedMessage ?: "Upload failed",
                )
            }
        }
    }

    fun cancelActiveUpload() {
        activeUploadTask?.cancel()
        activeUploadTask = null
        _uploadState.value = UploadProgressState(isUploading = false, progressFraction = 0f)
    }

    fun resetUploadState() {
        _uploadState.value = UploadProgressState()
    }

    fun updateProfile(displayName: String, username: String, bio: String) {
        viewModelScope.launch {
            repository.updateProfile(displayName, username, bio)
                .onSuccess { _snackbarMessage.value = "Profile updated" }
                .onFailure { _snackbarMessage.value = it.localizedMessage }
        }
    }

    fun setLanguage(code: String) {
        viewModelScope.launch {
            preferencesRepository.setLanguage(code)
            val current = preferences.value
            repository.syncAccountPreferences(code, current.themeMode, current.locationConsentGranted)
        }
    }

    fun setThemeMode(mode: ThemeModePreference) {
        viewModelScope.launch {
            preferencesRepository.setThemeMode(mode)
            val current = preferences.value
            repository.syncAccountPreferences(current.languageCode, mode, current.locationConsentGranted)
        }
    }

    fun setLocationConsent(granted: Boolean) {
        viewModelScope.launch {
            preferencesRepository.setLocationConsent(granted)
            val current = preferences.value
            repository.syncAccountPreferences(current.languageCode, current.themeMode, granted)
        }
    }

    fun deleteAccountAndData(onDeleted: () -> Unit) {
        viewModelScope.launch {
            repository.deleteAccountAndData()
                .onSuccess { onDeleted() }
                .onFailure { _snackbarMessage.value = it.localizedMessage }
        }
    }

    // --- Admin Actions ---

    fun adminRemoveVideo(videoId: String, reportId: String? = null) {
        viewModelScope.launch {
            repository.adminRemoveVideo(videoId, reportId)
                .onSuccess { _snackbarMessage.value = "Video removed" }
                .onFailure { _snackbarMessage.value = it.localizedMessage }
        }
    }

    fun adminDismissReport(reportId: String) {
        viewModelScope.launch {
            repository.adminDismissReport(reportId)
                .onFailure { _snackbarMessage.value = it.localizedMessage }
        }
    }

    fun adminSetUserBanned(targetUserId: String, banned: Boolean) {
        viewModelScope.launch {
            repository.adminSetUserBanned(targetUserId, banned)
                .onFailure { _snackbarMessage.value = it.localizedMessage }
        }
    }

    fun adminCreateCategory(nameAr: String, nameEn: String, slug: String, sortOrder: Long) {
        viewModelScope.launch {
            repository.adminCreateCategory(nameAr, nameEn, slug, sortOrder)
                .onSuccess { _snackbarMessage.value = "Category saved" }
                .onFailure { _snackbarMessage.value = it.localizedMessage }
        }
    }

    fun adminBroadcastAnnouncement(title: String, message: String) {
        viewModelScope.launch {
            repository.adminBroadcastAnnouncement(title, message)
                .onSuccess { _snackbarMessage.value = "Announcement sent" }
                .onFailure { _snackbarMessage.value = it.localizedMessage }
        }
    }

    fun adminPublishAppUpdate(
        versionCode: Long,
        versionName: String,
        notesAr: String,
        notesEn: String,
        downloadUrl: String,
        forceUpdate: Boolean,
    ) {
        viewModelScope.launch {
            repository.adminPublishAppUpdate(versionCode, versionName, notesAr, notesEn, downloadUrl, forceUpdate)
                .onSuccess { _snackbarMessage.value = "App update config published" }
                .onFailure { _snackbarMessage.value = it.localizedMessage }
        }
    }

    private fun extractRootFirestoreError(error: Throwable): Throwable {
        val firestoreError = generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
        if (firestoreError == null && error is CancellationException) throw error
        return firestoreError ?: error
    }

    private fun unwrapOrRethrow(error: Throwable, tagMethod: String) {
        val firestoreError = generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
        if (firestoreError == null && error is CancellationException) throw error
        Log.w(TAG, "Stream error in $tagMethod", firestoreError ?: error)
    }

    companion object {
        private const val TAG = "VideoPlusVM"
        private const val STOP_TIMEOUT_MS = 5000L
    }
}
