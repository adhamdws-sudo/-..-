package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Cinema Crimson & Obsidian Dark Palette
val CrimsonPrimaryDark = Color(0xFFFF3B5C)
val OnCrimsonDark = Color(0xFFFFFFFF)
val CrimsonContainerDark = Color(0xFF4A0E1B)
val OnCrimsonContainerDark = Color(0xFFFFD9DF)

val AmberSecondaryDark = Color(0xFFFFB800)
val OnAmberDark = Color(0xFF281800)
val AmberContainerDark = Color(0xFF442E00)
val OnAmberContainerDark = Color(0xFFFFE08A)

val EmeraldTertiaryDark = Color(0xFF10B981)
val ObsidianBackground = Color(0xFF0B0D12)
val CharcoalSurface = Color(0xFF12161F)
val SlateSurfaceVariant = Color(0xFF1C222F)
val ElevatedCardDark = Color(0xFF171C27)
val IvoryText = Color(0xFFF4F6FA)
val MutedSlateText = Color(0xFF9CA3AF)
val SubtleOutlineDark = Color(0xFF2B3242)

// Warm Alabaster & Studio Crimson Light Palette
val CrimsonPrimaryLight = Color(0xFFE11D48)
val OnCrimsonLight = Color(0xFFFFFFFF)
val CrimsonContainerLight = Color(0xFFFFE4E8)
val OnCrimsonContainerLight = Color(0xFF4C0519)

val AmberSecondaryLight = Color(0xFFD97706)
val OnAmberLight = Color(0xFFFFFFFF)
val AmberContainerLight = Color(0xFFFEF3C7)
val OnAmberContainerLight = Color(0xFF451A03)

val EmeraldTertiaryLight = Color(0xFF059669)
val AlabasterBackground = Color(0xFFFAF9F6)
val PureCloudSurface = Color(0xFFFFFFFF)
val SoftMistVariant = Color(0xFFF1F3F6)
val DeepInkText = Color(0xFF111827)
val MutedInkText = Color(0xFF6B7280)
val SubtleOutlineLight = Color(0xFFE5E7EB)
