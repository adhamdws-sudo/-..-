package com.example.ui

import android.net.Uri
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Subscriptions
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material.icons.filled.Whatshot
import androidx.compose.material.icons.outlined.AddCircleOutline
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Subscriptions
import androidx.compose.material.icons.outlined.VideoLibrary
import androidx.compose.material.icons.outlined.Whatshot
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.R
import com.example.data.PreferencesRepository
import com.example.data.UserPreferences
import com.example.data.VideoPlusRepository
import com.example.model.ThemeModePreference
import com.example.model.UiState
import com.example.ui.admin.AdminDashboardScreen
import com.example.ui.auth.AuthScreen
import com.example.ui.auth.authStateFlow
import com.example.ui.home.HomeScreen
import com.example.ui.i18n.ArabicStrings
import com.example.ui.i18n.EnglishStrings
import com.example.ui.i18n.LocalAppStrings
import com.example.ui.library.ChannelScreen
import com.example.ui.library.LibraryScreen
import com.example.ui.library.NotificationsScreen
import com.example.ui.library.PrivacyPolicyScreen
import com.example.ui.shorts.ShortsScreen
import com.example.ui.subscriptions.SubscriptionsScreen
import com.example.ui.theme.VideoPlusTheme
import com.example.ui.upload.CameraRecordScreen
import com.example.ui.upload.UploadScreen
import com.example.ui.watch.WatchScreen
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.launch

const val ROUTE_HOME = "home"
const val ROUTE_SHORTS = "shorts"
const val ROUTE_UPLOAD = "upload"
const val ROUTE_SUBSCRIPTIONS = "subscriptions"
const val ROUTE_LIBRARY = "library"
const val ROUTE_WATCH = "watch"
const val ROUTE_CHANNEL = "channel"
const val ROUTE_NOTIFICATIONS = "notifications"
const val ROUTE_PRIVACY = "privacy"
const val ROUTE_ADMIN = "admin"
const val ROUTE_CAMERA_RECORD = "camera_record"

@Composable
fun VideoPlusAppRoot(
    initialVideoIdFromIntent: String? = null,
    auth: FirebaseAuth = Firebase.auth,
) {
    val context = LocalContext.current
    val prefsRepo = remember(context) { PreferencesRepository(context.applicationContext) }
    val prefs by prefsRepo.preferencesFlow.collectAsStateWithLifecycle(initialValue = UserPreferences())
    val scope = rememberCoroutineScope()

    val currentUser by auth.authStateFlow().collectAsStateWithLifecycle(initialValue = auth.currentUser)
    var showPreAuthPrivacy by remember { mutableStateOf(false) }

    val isDark = when (prefs.themeMode) {
        ThemeModePreference.DARK -> true
        ThemeModePreference.LIGHT -> false
        ThemeModePreference.SYSTEM -> isSystemInDarkTheme()
    }
    val appStrings = if (prefs.languageCode == "en") EnglishStrings else ArabicStrings
    val layoutDirection = if (prefs.languageCode == "en") LayoutDirection.Ltr else LayoutDirection.Rtl

    CompositionLocalProvider(
        LocalAppStrings provides appStrings,
        LocalLayoutDirection provides layoutDirection,
    ) {
        VideoPlusTheme(darkTheme = isDark) {
            val user = currentUser
            if (user == null) {
                if (showPreAuthPrivacy) {
                    PrivacyPolicyScreen(onBack = { showPreAuthPrivacy = false })
                } else {
                    AuthScreen(
                        languageCode = prefs.languageCode,
                        onLanguageChange = { code -> scope.launch { prefsRepo.setLanguage(code) } },
                        onOpenPrivacyPolicy = { showPreAuthPrivacy = true },
                        onAuthSuccess = {}
                    )
                }
            } else {
                val uid = user.uid
                key(uid) {
                    val viewModel: VideoPlusViewModel = viewModel(
                        key = uid,
                        factory = viewModelFactory {
                            initializer {
                                val app = checkNotNull(this[APPLICATION_KEY]) {
                                    "APPLICATION_KEY missing"
                                }
                                val dbId = app.getString(R.string.firestore_database_id)
                                val db = FirebaseFirestore.getInstance(dbId)
                                VideoPlusViewModel(
                                    repository = VideoPlusRepository(db),
                                    preferencesRepository = PreferencesRepository(app),
                                    currentUserId = uid,
                                )
                            }
                        }
                    )
                    AuthenticatedAppShell(
                        viewModel = viewModel,
                        initialVideoIdFromIntent = initialVideoIdFromIntent,
                    )
                }
            }
        }
    }
}

@Composable
private fun AuthenticatedAppShell(
    viewModel: VideoPlusViewModel,
    initialVideoIdFromIntent: String?,
) {
    val strings = LocalAppStrings.current
    val context = LocalContext.current
    val navController = rememberNavController()
    val snackbarHostState = remember { SnackbarHostState() }

    val snackbarMsg by viewModel.snackbarMessage.collectAsStateWithLifecycle()
    val prefs by viewModel.preferences.collectAsStateWithLifecycle()
    val profile by viewModel.currentUserProfile.collectAsStateWithLifecycle()
    val privateAcc by viewModel.privateAccount.collectAsStateWithLifecycle()
    val videosState by viewModel.publicVideosState.collectAsStateWithLifecycle()
    val myVideos by viewModel.myVideos.collectAsStateWithLifecycle()
    val savedVideos by viewModel.savedVideos.collectAsStateWithLifecycle()
    val watchHistory by viewModel.watchHistory.collectAsStateWithLifecycle()
    val subscriptions by viewModel.subscriptions.collectAsStateWithLifecycle()
    val notifications by viewModel.notifications.collectAsStateWithLifecycle()
    val categories by viewModel.categories.collectAsStateWithLifecycle()
    val announcements by viewModel.announcements.collectAsStateWithLifecycle()
    val cloudConfig by viewModel.cloudConfig.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val selectedCategory by viewModel.selectedCategory.collectAsStateWithLifecycle()
    val feedMode by viewModel.feedMode.collectAsStateWithLifecycle()
    val hasMorePages by viewModel.hasMorePages.collectAsStateWithLifecycle()
    val uploadState by viewModel.uploadState.collectAsStateWithLifecycle()
    val isAdmin by viewModel.isAdmin.collectAsStateWithLifecycle()

    val activeVideo by viewModel.activeVideo.collectAsStateWithLifecycle()
    val activeVideoVote by viewModel.activeVideoVote.collectAsStateWithLifecycle()
    val activeVideoComments by viewModel.activeVideoComments.collectAsStateWithLifecycle()
    val viewedChannelProfile by viewModel.viewedChannelProfile.collectAsStateWithLifecycle()
    val adminReports by viewModel.adminReports.collectAsStateWithLifecycle()
    val adminUsers by viewModel.adminUsers.collectAsStateWithLifecycle()

    var recordedVideoUri by remember { mutableStateOf<Uri?>(null) }
    var selectedShortId by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(snackbarMsg) {
        val msg = snackbarMsg
        if (!msg.isNullOrBlank()) {
            snackbarHostState.showSnackbar(msg)
            viewModel.clearSnackbar()
        }
    }

    LaunchedEffect(initialVideoIdFromIntent) {
        if (!initialVideoIdFromIntent.isNullOrBlank()) {
            viewModel.openVideo(initialVideoIdFromIntent)
            navController.navigate("$ROUTE_WATCH/$initialVideoIdFromIntent")
        }
    }

    val allVideos = (videosState as? UiState.Success)?.data ?: emptyList()
    val blockedSet = remember(privateAcc) { privateAcc?.blockedUserIds?.toSet() ?: emptySet() }
    val unreadNotifCount = remember(notifications) { notifications.count { !it.readFlag } }

    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route
    val showBottomChrome = currentRoute in setOf(
        ROUTE_HOME,
        ROUTE_SHORTS,
        ROUTE_UPLOAD,
        ROUTE_SUBSCRIPTIONS,
        ROUTE_LIBRARY,
    )

    val topDestinations = listOf(
        Triple(ROUTE_HOME, strings.navHome, Icons.Filled.Home to Icons.Outlined.Home),
        Triple(ROUTE_SHORTS, strings.navShorts, Icons.Filled.Whatshot to Icons.Outlined.Whatshot),
        Triple(ROUTE_UPLOAD, strings.navUpload, Icons.Filled.AddCircle to Icons.Outlined.AddCircleOutline),
        Triple(ROUTE_SUBSCRIPTIONS, strings.navSubscriptions, Icons.Filled.Subscriptions to Icons.Outlined.Subscriptions),
        Triple(ROUTE_LIBRARY, strings.navLibrary, Icons.Filled.VideoLibrary to Icons.Outlined.VideoLibrary),
    )

    fun navigateTopTab(route: String) {
        navController.navigate(route) {
            popUpTo(navController.graph.findStartDestination().id) { saveState = true }
            launchSingleTop = true
            restoreState = true
        }
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useNavRail = maxWidth >= 600.dp

        Scaffold(
            contentWindowInsets = WindowInsets.safeDrawing,
            snackbarHost = { SnackbarHost(snackbarHostState) },
            bottomBar = {
                if (showBottomChrome && !useNavRail) {
                    NavigationBar {
                        topDestinations.forEach { (route, label, icons) ->
                            val selected = currentRoute == route
                            NavigationBarItem(
                                selected = selected,
                                onClick = { navigateTopTab(route) },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) icons.first else icons.second,
                                        contentDescription = label
                                    )
                                },
                                label = { Text(label, maxLines = 1) },
                                modifier = Modifier.testTag("nav_tab_$route")
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (showBottomChrome && useNavRail) {
                    NavigationRail {
                        topDestinations.forEach { (route, label, icons) ->
                            val selected = currentRoute == route
                            NavigationRailItem(
                                selected = selected,
                                onClick = { navigateTopTab(route) },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) icons.first else icons.second,
                                        contentDescription = label
                                    )
                                },
                                label = { Text(label) },
                                modifier = Modifier.testTag("rail_tab_$route")
                            )
                        }
                    }
                }

                Box(modifier = Modifier.weight(1f)) {
                    NavHost(
                        navController = navController,
                        startDestination = ROUTE_HOME,
                    ) {
                        composable(ROUTE_HOME) {
                            HomeScreen(
                                videosState = videosState,
                                categories = categories,
                                announcements = announcements,
                                cloudConfig = cloudConfig,
                                searchQuery = searchQuery,
                                selectedCategory = selectedCategory,
                                feedMode = feedMode,
                                blockedUserIds = blockedSet,
                                unreadNotificationsCount = unreadNotifCount,
                                hasMorePages = hasMorePages,
                                onSearchChange = viewModel::updateSearchQuery,
                                onCategorySelected = viewModel::selectCategory,
                                onFeedModeSelected = viewModel::selectFeedMode,
                                onLoadMore = viewModel::loadMoreVideos,
                                onVideoClick = { vid ->
                                    viewModel.openVideo(vid)
                                    navController.navigate("$ROUTE_WATCH/$vid")
                                },
                                onShortClick = { vid ->
                                    selectedShortId = vid
                                    navigateTopTab(ROUTE_SHORTS)
                                },
                                onChannelClick = { cid ->
                                    viewModel.openChannel(cid)
                                    navController.navigate("$ROUTE_CHANNEL/$cid")
                                },
                                onNotificationsClick = {
                                    navController.navigate(ROUTE_NOTIFICATIONS)
                                }
                            )
                        }

                        composable(ROUTE_SHORTS) {
                            val shorts = remember(allVideos, blockedSet) {
                                allVideos.filter { it.shortVideo && it.authorId !in blockedSet }
                            }
                            ShortsScreen(
                                shorts = shorts,
                                initialVideoId = selectedShortId,
                                onRecordView = { v -> viewModel.recordVideoView(v, 0L) },
                                onVote = viewModel::toggleVote,
                                onOpenFullPlayer = { vid ->
                                    viewModel.openVideo(vid)
                                    navController.navigate("$ROUTE_WATCH/$vid")
                                },
                                onChannelClick = { cid ->
                                    viewModel.openChannel(cid)
                                    navController.navigate("$ROUTE_CHANNEL/$cid")
                                }
                            )
                        }

                        composable(ROUTE_UPLOAD) {
                            UploadScreen(
                                recordedVideoUri = recordedVideoUri,
                                categories = categories,
                                uploadState = uploadState,
                                locationConsentGranted = prefs.locationConsentGranted,
                                onGrantLocationConsent = viewModel::setLocationConsent,
                                onOpenCameraRecorder = { navController.navigate(ROUTE_CAMERA_RECORD) },
                                onPublish = { vUri, tUri, title, desc, cat, priv, shortV, dur, loc ->
                                    viewModel.uploadVideo(
                                        context = context,
                                        videoUri = vUri,
                                        thumbnailUri = tUri,
                                        title = title,
                                        description = desc,
                                        category = cat,
                                        privacy = priv,
                                        shortVideo = shortV,
                                        durationSec = dur,
                                        locationLabel = loc,
                                    )
                                },
                                onCancelUpload = viewModel::cancelActiveUpload,
                                onResetUploadState = viewModel::resetUploadState,
                                onWatchPublished = { vid ->
                                    viewModel.openVideo(vid)
                                    navController.navigate("$ROUTE_WATCH/$vid")
                                }
                            )
                        }

                        composable(ROUTE_CAMERA_RECORD) {
                            CameraRecordScreen(
                                onVideoRecorded = { uri ->
                                    recordedVideoUri = uri
                                    navController.popBackStack()
                                },
                                onBack = { navController.popBackStack() }
                            )
                        }

                        composable(ROUTE_SUBSCRIPTIONS) {
                            SubscriptionsScreen(
                                subscriptions = subscriptions,
                                allVideos = allVideos.filter { it.authorId !in blockedSet },
                                onVideoClick = { vid ->
                                    viewModel.openVideo(vid)
                                    navController.navigate("$ROUTE_WATCH/$vid")
                                },
                                onChannelClick = { cid ->
                                    viewModel.openChannel(cid)
                                    navController.navigate("$ROUTE_CHANNEL/$cid")
                                }
                            )
                        }

                        composable(ROUTE_LIBRARY) {
                            LibraryScreen(
                                profile = profile,
                                myVideos = myVideos,
                                savedVideos = savedVideos,
                                watchHistory = watchHistory,
                                blockedUserIds = privateAcc?.blockedUserIds ?: emptyList(),
                                preferences = prefs,
                                isAdmin = isAdmin,
                                onEditProfile = viewModel::updateProfile,
                                onVideoClick = { vid ->
                                    viewModel.openVideo(vid)
                                    navController.navigate("$ROUTE_WATCH/$vid")
                                },
                                onUnblockUser = { uid -> viewModel.toggleBlockUser(uid, false) },
                                onLanguageChange = viewModel::setLanguage,
                                onThemeChange = viewModel::setThemeMode,
                                onOpenPrivacyPolicy = { navController.navigate(ROUTE_PRIVACY) },
                                onOpenAdminDashboard = { navController.navigate(ROUTE_ADMIN) },
                                onDeleteAccount = viewModel::deleteAccountAndData,
                            )
                        }

                        composable(
                            route = "$ROUTE_WATCH/{videoId}",
                            arguments = listOf(navArgument("videoId") { type = NavType.StringType })
                        ) { entry ->
                            val videoId = entry.arguments?.getString("videoId") ?: ""
                            LaunchedEffect(videoId) { viewModel.openVideo(videoId) }
                            val isSaved = savedVideos.any { it.videoId == videoId }
                            val isSub = activeVideo?.let { v -> subscriptions.any { it.channelId == v.authorId } } ?: false
                            val upNext = remember(allVideos, videoId, blockedSet) {
                                allVideos.filter { it.id != videoId && it.authorId !in blockedSet }
                            }
                            WatchScreen(
                                video = activeVideo,
                                currentUserId = viewModel.currentUserId,
                                userVote = activeVideoVote,
                                isSaved = isSaved,
                                isSubscribed = isSub,
                                comments = activeVideoComments,
                                upNextVideos = upNext,
                                onBack = { navController.popBackStack() },
                                onRecordView = viewModel::recordVideoView,
                                onVote = viewModel::toggleVote,
                                onToggleSave = viewModel::toggleSave,
                                onToggleSubscribe = { v, sub ->
                                    viewModel.toggleSubscription(v.authorId, v.authorName, v.authorAvatarUrl, sub)
                                },
                                onAddComment = viewModel::addComment,
                                onReportVideo = viewModel::reportVideo,
                                onBlockCreator = { creatorId -> viewModel.toggleBlockUser(creatorId, true) },
                                onOpenNextVideo = { nextId ->
                                    viewModel.openVideo(nextId)
                                    navController.navigate("$ROUTE_WATCH/$nextId") {
                                        popUpTo("$ROUTE_WATCH/$videoId") { inclusive = true }
                                    }
                                },
                                onOpenChannel = { cid ->
                                    viewModel.openChannel(cid)
                                    navController.navigate("$ROUTE_CHANNEL/$cid")
                                }
                            )
                        }

                        composable(
                            route = "$ROUTE_CHANNEL/{channelId}",
                            arguments = listOf(navArgument("channelId") { type = NavType.StringType })
                        ) { entry ->
                            val channelId = entry.arguments?.getString("channelId") ?: ""
                            LaunchedEffect(channelId) { viewModel.openChannel(channelId) }
                            val isSub = subscriptions.any { it.channelId == channelId }
                            val channelVideos = remember(allVideos, channelId) {
                                allVideos.filter { it.authorId == channelId }
                            }
                            ChannelScreen(
                                channelProfile = viewedChannelProfile,
                                channelVideos = channelVideos,
                                currentUserId = viewModel.currentUserId,
                                isSubscribed = isSub,
                                onToggleSubscribe = { ch, sub ->
                                    viewModel.toggleSubscription(ch.userId, ch.displayName, ch.avatarUrl, sub)
                                },
                                onVideoClick = { vid ->
                                    viewModel.openVideo(vid)
                                    navController.navigate("$ROUTE_WATCH/$vid")
                                },
                                onBack = { navController.popBackStack() }
                            )
                        }

                        composable(ROUTE_NOTIFICATIONS) {
                            NotificationsScreen(
                                notifications = notifications,
                                onNotificationClick = { item ->
                                    viewModel.markNotificationRead(item.id)
                                    if (!item.targetVideoId.isNullOrBlank()) {
                                        viewModel.openVideo(item.targetVideoId)
                                        navController.navigate("$ROUTE_WATCH/${item.targetVideoId}")
                                    }
                                },
                                onBack = { navController.popBackStack() }
                            )
                        }

                        composable(ROUTE_PRIVACY) {
                            PrivacyPolicyScreen(onBack = { navController.popBackStack() })
                        }

                        composable(ROUTE_ADMIN) {
                            if (isAdmin) {
                                AdminDashboardScreen(
                                    videos = allVideos,
                                    reports = adminReports,
                                    users = adminUsers,
                                    categories = categories,
                                    onRemoveVideo = viewModel::adminRemoveVideo,
                                    onDismissReport = viewModel::adminDismissReport,
                                    onSetUserBanned = viewModel::adminSetUserBanned,
                                    onCreateCategory = viewModel::adminCreateCategory,
                                    onBroadcastAnnouncement = viewModel::adminBroadcastAnnouncement,
                                    onPublishAppUpdate = viewModel::adminPublishAppUpdate,
                                    onBack = { navController.popBackStack() }
                                )
                            } else {
                                LaunchedEffect(Unit) { navController.popBackStack() }
                            }
                        }
                    }
                }
            }
        }
    }
}
