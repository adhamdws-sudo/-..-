package com.example.ui.library

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.ui.i18n.LocalAppStrings

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PrivacyPolicyScreen(
    onBack: () -> Unit,
) {
    val strings = LocalAppStrings.current
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(strings.privacyPolicy) },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("privacy_back_button")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = strings.back)
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(20.dp)
        ) {
            val sections = if (strings.isArabic) {
                listOf(
                    "1. البيانات التي نجمعها" to "نجمع فقط البيانات اللازمة لتشغيل حسابك وقناتك عبر Google Sign-In وFirebase Authentication (الاسم، البريد الإلكتروني في سجل خاص محمي، والصورة الشخصية)، بالإضافة إلى الفيديوهات والتعليقات والتفاعلات التي تنشئها طوعاً.",
                    "2. الأذونات الاختيارية" to "• الكاميرا والميكروفون: تُطلب فقط عند اختيارك تسجيل فيديو داخل التطبيق.\n• الصور والفيديوهات: نستخدم منتقي الوسائط الرسمي (Android Photo Picker) دون طلب صلاحية الوصول الشامل لملفاتك.\n• الإشعارات: تُطلب على Android 13+ فقط لتنبيهات المحتوى والاشتراكات.\n• الموقع الجغرافي التقريبي: اختياري تماماً وبموافقتك المسبقة لإرفاق اسم المدينة بالفيديو فقط، ولا نجمع الموقع في الخلفية.",
                    "3. حماية البيانات والحذف" to "تُحفظ البيانات على خدمات Google Firebase المحمية بقواعد أمان صارمة. يمكنك في أي وقت تعديل ملفك الشخصي أو حذف حسابك وجميع بياناتك الخاصة وسجل المشاهدة نهائياً من صفحة المكتبة / الإعدادات.",
                )
            } else {
                listOf(
                    "1. Data We Collect" to "We collect only the minimum data needed to run your channel via Google Sign-In and Firebase Authentication (display name, private email record, avatar), plus the videos, comments, and interactions you voluntarily publish.",
                    "2. Optional Permissions" to "• Camera & Microphone: Requested only when you tap Record Video inside the app.\n• Photos & Videos: Selected using the zero-permission Android Photo Picker without broad storage access.\n• Notifications: Requested on Android 13+ for channel updates and replies.\n• Approximate Location: Strictly optional with explicit opt-in consent to attach a city tag to an upload; background location is never collected.",
                    "3. Data Security & Deletion" to "All cloud records are isolated under strict Firebase security rules. You can edit your profile or permanently delete your account, private settings, and watch history anytime from Library > Settings.",
                )
            }

            sections.forEach { (title, body) ->
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = body,
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Spacer(modifier = Modifier.height(18.dp))
            }
        }
    }
}
