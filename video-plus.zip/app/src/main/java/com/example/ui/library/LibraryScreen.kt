package com.example.ui.library

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.PrivacyTip
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.credentials.CredentialManager
import coil.compose.AsyncImage
import com.example.data.UserPreferences
import com.example.model.PublicProfile
import com.example.model.SavedVideoRef
import com.example.model.ThemeModePreference
import com.example.model.VideoItem
import com.example.model.WatchHistoryItem
import com.example.ui.auth.signOutUser
import com.example.ui.components.AvatarCircle
import com.example.ui.components.formatCompactCount
import com.example.ui.components.formatDuration
import com.example.ui.i18n.LocalAppStrings

@Composable
fun LibraryScreen(
    profile: PublicProfile?,
    myVideos: List<VideoItem>,
    savedVideos: List<SavedVideoRef>,
    watchHistory: List<WatchHistoryItem>,
    blockedUserIds: List<String>,
    preferences: UserPreferences,
    isAdmin: Boolean,
    onEditProfile: (String, String, String) -> Unit,
    onVideoClick: (String) -> Unit,
    onUnblockUser: (String) -> Unit,
    onLanguageChange: (String) -> Unit,
    onThemeChange: (ThemeModePreference) -> Unit,
    onOpenPrivacyPolicy: () -> Unit,
    onOpenAdminDashboard: () -> Unit,
    onDeleteAccount: (onDeleted: () -> Unit) -> Unit,
) {
    val strings = LocalAppStrings.current
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember(context) { CredentialManager.create(context) }

    var showEditDialog by remember { mutableStateOf(false) }
    var showDeleteDialog by remember { mutableStateOf(false) }
    var notificationsGranted by remember {
        mutableStateOf(
            Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
                ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        )
    }

    val notificationPermLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        notificationsGranted = granted
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Profile Header Card
        item(key = "profile_card") {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(20.dp)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        AvatarCircle(
                            name = profile?.displayName ?: "V",
                            avatarUrl = profile?.avatarUrl,
                            sizeDp = 64
                        )
                        Spacer(modifier = Modifier.width(14.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = profile?.displayName ?: "Creator",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "@${profile?.username ?: "creator"}",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = "${formatCompactCount(profile?.subscribersCount ?: 0L)} ${strings.subscribersLabel} • ${profile?.videosCount ?: 0L} ${strings.myVideos}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        OutlinedButton(
                            onClick = { showEditDialog = true },
                            modifier = Modifier.testTag("library_edit_profile_button")
                        ) {
                            Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(strings.editProfile)
                        }
                    }
                    if (!profile?.bio.isNullOrBlank()) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = profile?.bio ?: "",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        // Server-Verified Admin Entry (Strictly hidden unless verified admin)
        if (isAdmin) {
            item(key = "admin_entry") {
                Button(
                    onClick = onOpenAdminDashboard,
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("library_admin_dashboard_button")
                ) {
                    Icon(Icons.Default.AdminPanelSettings, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(strings.adminDashboard, style = MaterialTheme.typography.labelLarge)
                }
            }
        }

        // My Videos
        if (myVideos.isNotEmpty()) {
            item(key = "my_videos_section") {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.VideoLibrary, contentDescription = null, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("${strings.myVideos} (${myVideos.size})", style = MaterialTheme.typography.titleMedium)
                    }
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        items(myVideos, key = { it.id }) { v ->
                            MiniVideoCard(
                                title = v.title,
                                subtitle = "${v.privacy} • ${formatDuration(v.durationSec)}",
                                thumbnailUrl = v.thumbnailUrl,
                                onClick = { onVideoClick(v.id) }
                            )
                        }
                    }
                }
            }
        }

        // Saved Videos
        if (savedVideos.isNotEmpty()) {
            item(key = "saved_section") {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Bookmark, contentDescription = null, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("${strings.savedVideos} (${savedVideos.size})", style = MaterialTheme.typography.titleMedium)
                    }
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        items(savedVideos, key = { it.videoId }) { s ->
                            MiniVideoCard(
                                title = s.title,
                                subtitle = s.authorName,
                                thumbnailUrl = s.thumbnailUrl ?: "",
                                onClick = { onVideoClick(s.videoId) }
                            )
                        }
                    }
                }
            }
        }

        // Watch History
        if (watchHistory.isNotEmpty()) {
            item(key = "history_section") {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.History, contentDescription = null, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("${strings.watchHistory} (${watchHistory.size})", style = MaterialTheme.typography.titleMedium)
                    }
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        items(watchHistory, key = { it.videoId }) { h ->
                            MiniVideoCard(
                                title = h.title,
                                subtitle = h.authorName,
                                thumbnailUrl = h.thumbnailUrl ?: "",
                                onClick = { onVideoClick(h.videoId) }
                            )
                        }
                    }
                }
            }
        }

        // Blocked Users
        if (blockedUserIds.isNotEmpty()) {
            item(key = "blocked_users_card") {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(strings.blockedUsers, style = MaterialTheme.typography.titleMedium)
                        blockedUserIds.forEach { blockedUid ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(blockedUid, style = MaterialTheme.typography.bodyMedium)
                                TextButton(onClick = { onUnblockUser(blockedUid) }) {
                                    Text(strings.unblock)
                                }
                            }
                        }
                    }
                }
            }
        }

        // Settings Card
        item(key = "settings_card") {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(20.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(strings.settings, style = MaterialTheme.typography.titleMedium)

                    Text(strings.languageLabel, style = MaterialTheme.typography.labelLarge)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = preferences.languageCode == "ar",
                            onClick = { onLanguageChange("ar") },
                            label = { Text("العربية (RTL)") },
                            modifier = Modifier.testTag("settings_lang_ar")
                        )
                        FilterChip(
                            selected = preferences.languageCode == "en",
                            onClick = { onLanguageChange("en") },
                            label = { Text("English (LTR)") },
                            modifier = Modifier.testTag("settings_lang_en")
                        )
                    }

                    Text(strings.themeLabel, style = MaterialTheme.typography.labelLarge)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = preferences.themeMode == ThemeModePreference.SYSTEM,
                            onClick = { onThemeChange(ThemeModePreference.SYSTEM) },
                            label = { Text(strings.themeSystem) }
                        )
                        FilterChip(
                            selected = preferences.themeMode == ThemeModePreference.LIGHT,
                            onClick = { onThemeChange(ThemeModePreference.LIGHT) },
                            label = { Text(strings.themeLight) }
                        )
                        FilterChip(
                            selected = preferences.themeMode == ThemeModePreference.DARK,
                            onClick = { onThemeChange(ThemeModePreference.DARK) },
                            label = { Text(strings.themeDark) }
                        )
                    }

                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && !notificationsGranted) {
                        OutlinedButton(
                            onClick = { notificationPermLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.NotificationsActive, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(strings.permissionRationaleNotifications)
                        }
                    }

                    OutlinedButton(
                        onClick = onOpenPrivacyPolicy,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("settings_privacy_button")
                    ) {
                        Icon(Icons.Default.PrivacyTip, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(strings.privacyPolicy)
                    }

                    OutlinedButton(
                        onClick = {
                            signOutUser(credentialManager, scope)
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("settings_sign_out_button")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(strings.signOut)
                    }

                    TextButton(
                        onClick = { showDeleteDialog = true },
                        colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("settings_delete_account_button")
                    ) {
                        Icon(Icons.Default.DeleteForever, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(strings.deleteAccount)
                    }
                }
            }
        }
    }

    if (showEditDialog) {
        var displayName by remember(profile) { mutableStateOf(profile?.displayName ?: "") }
        var username by remember(profile) { mutableStateOf(profile?.username ?: "") }
        var bio by remember(profile) { mutableStateOf(profile?.bio ?: "") }
        AlertDialog(
            onDismissRequest = { showEditDialog = false },
            title = { Text(strings.editProfile) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(value = displayName, onValueChange = { displayName = it }, label = { Text(strings.displayNameLabel) })
                    OutlinedTextField(value = username, onValueChange = { username = it }, label = { Text(strings.usernameLabel) })
                    OutlinedTextField(value = bio, onValueChange = { bio = it }, label = { Text(strings.bioLabel) })
                }
            },
            confirmButton = {
                Button(onClick = {
                    onEditProfile(displayName, username, bio)
                    showEditDialog = false
                }) { Text(strings.saveChanges) }
            },
            dismissButton = {
                TextButton(onClick = { showEditDialog = false }) { Text(strings.cancel) }
            }
        )
    }

    if (showDeleteDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteDialog = false },
            title = { Text(strings.deleteAccountConfirmTitle) },
            text = { Text(strings.deleteAccountConfirmBody) },
            confirmButton = {
                Button(
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                    onClick = {
                        showDeleteDialog = false
                        onDeleteAccount {
                            signOutUser(credentialManager, scope)
                        }
                    }
                ) { Text(strings.confirm) }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteDialog = false }) { Text(strings.cancel) }
            }
        )
    }
}

@Composable
private fun MiniVideoCard(
    title: String,
    subtitle: String,
    thumbnailUrl: String,
    onClick: () -> Unit,
) {
    Card(
        modifier = Modifier
            .width(172.dp)
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column {
            if (thumbnailUrl.isNotBlank()) {
                AsyncImage(
                    model = thumbnailUrl,
                    contentDescription = title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(96.dp)
                        .clip(RoundedCornerShape(topStart = 14.dp, topEnd = 14.dp))
                )
            } else {
                Spacer(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(96.dp)
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                )
            }
            Column(modifier = Modifier.padding(10.dp)) {
                Text(title, style = MaterialTheme.typography.labelLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(subtitle, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
            }
        }
    }
}
