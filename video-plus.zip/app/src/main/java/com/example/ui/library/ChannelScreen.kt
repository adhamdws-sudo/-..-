package com.example.ui.library

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.model.PublicProfile
import com.example.model.VideoItem
import com.example.ui.components.AvatarCircle
import com.example.ui.components.EmptyVideosIllustration
import com.example.ui.components.VideoFeedCard
import com.example.ui.components.formatCompactCount
import com.example.ui.i18n.LocalAppStrings

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChannelScreen(
    channelProfile: PublicProfile?,
    channelVideos: List<VideoItem>,
    currentUserId: String,
    isSubscribed: Boolean,
    onToggleSubscribe: (PublicProfile, Boolean) -> Unit,
    onVideoClick: (String) -> Unit,
    onBack: () -> Unit,
) {
    val strings = LocalAppStrings.current
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(channelProfile?.displayName ?: "") },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("channel_back_button")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = strings.back)
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            if (channelProfile != null) {
                item(key = "channel_banner") {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(20.dp)
                    ) {
                        Column(modifier = Modifier.padding(18.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                AvatarCircle(channelProfile.displayName, channelProfile.avatarUrl, sizeDp = 64)
                                Spacer(modifier = Modifier.width(14.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(channelProfile.displayName, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                                    Text("@${channelProfile.username}", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.primary)
                                    Text(
                                        text = "${formatCompactCount(channelProfile.subscribersCount)} ${strings.subscribersLabel}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                if (channelProfile.userId != currentUserId) {
                                    Button(
                                        onClick = { onToggleSubscribe(channelProfile, isSubscribed) },
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = if (isSubscribed) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.primary,
                                            contentColor = if (isSubscribed) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onPrimary
                                        )
                                    ) {
                                        Text(if (isSubscribed) strings.subscribed else strings.subscribe)
                                    }
                                }
                            }
                            if (!channelProfile.bio.isNullOrBlank()) {
                                Spacer(modifier = Modifier.height(10.dp))
                                Text(channelProfile.bio, style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                    }
                }
            }

            if (channelVideos.isEmpty()) {
                item(key = "empty_channel") {
                    EmptyVideosIllustration(title = strings.emptyVideosTitle, body = strings.emptyVideosBody)
                }
            } else {
                items(channelVideos, key = { it.id }) { video ->
                    VideoFeedCard(
                        video = video,
                        onClick = { onVideoClick(video.id) },
                        onChannelClick = {}
                    )
                }
            }
        }
    }
}
