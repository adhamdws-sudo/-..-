package com.example.ui.shorts

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Comment
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.ThumbDown
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.example.model.VideoItem
import com.example.model.VoteType
import com.example.ui.components.AvatarCircle
import com.example.ui.components.EmptyVideosIllustration
import com.example.ui.components.formatCompactCount
import com.example.ui.i18n.LocalAppStrings

@Composable
fun ShortsScreen(
    shorts: List<VideoItem>,
    initialVideoId: String?,
    onRecordView: (VideoItem) -> Unit,
    onVote: (String, VoteType) -> Unit,
    onOpenFullPlayer: (String) -> Unit,
    onChannelClick: (String) -> Unit,
) {
    val strings = LocalAppStrings.current
    if (shorts.isEmpty()) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background),
            contentAlignment = Alignment.Center
        ) {
            EmptyVideosIllustration(
                title = strings.shortsShelf,
                body = strings.emptyVideosBody
            )
        }
        return
    }

    val startIndex = remember(shorts, initialVideoId) {
        val idx = shorts.indexOfFirst { it.id == initialVideoId }
        if (idx >= 0) idx else 0
    }
    val pagerState = rememberPagerState(initialPage = startIndex, pageCount = { shorts.size })

    VerticalPager(
        state = pagerState,
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .testTag("shorts_vertical_pager")
    ) { page ->
        val video = shorts[page]
        val isActivePage = pagerState.currentPage == page
        ShortVideoPage(
            video = video,
            isActive = isActivePage,
            onRecordView = { onRecordView(video) },
            onLike = { onVote(video.id, VoteType.LIKE) },
            onDislike = { onVote(video.id, VoteType.DISLIKE) },
            onOpenComments = { onOpenFullPlayer(video.id) },
            onChannelClick = { onChannelClick(video.authorId) }
        )
    }
}

@androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
@Composable
private fun ShortVideoPage(
    video: VideoItem,
    isActive: Boolean,
    onRecordView: () -> Unit,
    onLike: () -> Unit,
    onDislike: () -> Unit,
    onOpenComments: () -> Unit,
    onChannelClick: () -> Unit,
) {
    val strings = LocalAppStrings.current
    val context = LocalContext.current

    val exoPlayer = remember(video.id, video.videoUrl) {
        ExoPlayer.Builder(context).build().apply {
            repeatMode = Player.REPEAT_MODE_ONE
            setMediaItem(MediaItem.fromUri(video.videoUrl))
            prepare()
        }
    }

    LaunchedEffect(isActive) {
        exoPlayer.playWhenReady = isActive
        if (isActive) {
            onRecordView()
        }
    }

    DisposableEffect(video.id) {
        onDispose {
            exoPlayer.release()
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        AndroidView(
            factory = { ctx ->
                PlayerView(ctx).apply {
                    useController = false
                    resizeMode = AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                    player = exoPlayer
                }
            },
            update = { view -> view.player = exoPlayer },
            modifier = Modifier.fillMaxSize()
        )

        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(Color.Transparent, Color.Transparent, Color(0xCC000000))
                    )
                )
        )

        // Right-side action rail
        Column(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(end = 14.dp, bottom = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            IconButton(onClick = onLike, modifier = Modifier.testTag("short_like_btn")) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.ThumbUp, contentDescription = strings.like, tint = Color.White)
                    Text(formatCompactCount(video.likesCount), style = MaterialTheme.typography.labelSmall, color = Color.White)
                }
            }
            IconButton(onClick = onDislike, modifier = Modifier.testTag("short_dislike_btn")) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.ThumbDown, contentDescription = strings.dislike, tint = Color.White)
                    Text(formatCompactCount(video.dislikesCount), style = MaterialTheme.typography.labelSmall, color = Color.White)
                }
            }
            IconButton(onClick = onOpenComments, modifier = Modifier.testTag("short_comments_btn")) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.AutoMirrored.Filled.Comment, contentDescription = strings.commentsTitle, tint = Color.White)
                    Text(formatCompactCount(video.commentsCount), style = MaterialTheme.typography.labelSmall, color = Color.White)
                }
            }
            IconButton(
                onClick = {
                    val shareIntent = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_SUBJECT, video.title)
                        putExtra(Intent.EXTRA_TEXT, "${video.title}\n${video.videoUrl}")
                    }
                    context.startActivity(Intent.createChooser(shareIntent, strings.share))
                },
                modifier = Modifier.testTag("short_share_btn")
            ) {
                Icon(Icons.Default.Share, contentDescription = strings.share, tint = Color.White)
            }
        }

        // Bottom metadata
        Column(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .fillMaxWidth(0.78f)
                .padding(start = 16.dp, bottom = 28.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                AvatarCircle(
                    name = video.authorName,
                    avatarUrl = video.authorAvatarUrl,
                    sizeDp = 38,
                    onClick = onChannelClick
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = "@${video.authorName}",
                    style = MaterialTheme.typography.titleSmall,
                    color = Color.White
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = video.title,
                style = MaterialTheme.typography.bodyLarge,
                color = Color.White
            )
            if (video.description.isNotBlank()) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = video.description,
                    style = MaterialTheme.typography.bodySmall,
                    color = Color(0xFFD1D5DB),
                    maxLines = 2
                )
            }
        }
    }
}
