package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

private val VideoPlusDarkScheme = darkColorScheme(
    primary = CrimsonPrimaryDark,
    onPrimary = OnCrimsonDark,
    primaryContainer = CrimsonContainerDark,
    onPrimaryContainer = OnCrimsonContainerDark,
    secondary = AmberSecondaryDark,
    onSecondary = OnAmberDark,
    secondaryContainer = AmberContainerDark,
    onSecondaryContainer = OnAmberContainerDark,
    tertiary = EmeraldTertiaryDark,
    background = ObsidianBackground,
    onBackground = IvoryText,
    surface = CharcoalSurface,
    onSurface = IvoryText,
    surfaceVariant = SlateSurfaceVariant,
    onSurfaceVariant = MutedSlateText,
    surfaceContainer = ElevatedCardDark,
    outline = SubtleOutlineDark,
)

private val VideoPlusLightScheme = lightColorScheme(
    primary = CrimsonPrimaryLight,
    onPrimary = OnCrimsonLight,
    primaryContainer = CrimsonContainerLight,
    onPrimaryContainer = OnCrimsonContainerLight,
    secondary = AmberSecondaryLight,
    onSecondary = OnAmberLight,
    secondaryContainer = AmberContainerLight,
    onSecondaryContainer = OnAmberContainerLight,
    tertiary = EmeraldTertiaryLight,
    background = AlabasterBackground,
    onBackground = DeepInkText,
    surface = PureCloudSurface,
    onSurface = DeepInkText,
    surfaceVariant = SoftMistVariant,
    onSurfaceVariant = MutedInkText,
    surfaceContainer = PureCloudSurface,
    outline = SubtleOutlineLight,
)

val VideoPlusShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp),
)

@Composable
fun VideoPlusTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit,
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> VideoPlusDarkScheme
        else -> VideoPlusLightScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = VideoPlusTypography,
        shapes = VideoPlusShapes,
        content = content,
    )
}
