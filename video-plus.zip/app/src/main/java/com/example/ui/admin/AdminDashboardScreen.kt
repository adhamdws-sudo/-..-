package com.example.ui.admin

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.model.PublicProfile
import com.example.model.VideoCategory
import com.example.model.VideoItem
import com.example.model.VideoReport
import com.example.ui.components.formatCompactCount
import com.example.ui.i18n.LocalAppStrings

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminDashboardScreen(
    videos: List<VideoItem>,
    reports: List<VideoReport>,
    users: List<PublicProfile>,
    categories: List<VideoCategory>,
    onRemoveVideo: (videoId: String, reportId: String?) -> Unit,
    onDismissReport: (String) -> Unit,
    onSetUserBanned: (String, Boolean) -> Unit,
    onCreateCategory: (String, String, String, Long) -> Unit,
    onBroadcastAnnouncement: (String, String) -> Unit,
    onPublishAppUpdate: (Long, String, String, String, String, Boolean) -> Unit,
    onBack: () -> Unit,
) {
    val strings = LocalAppStrings.current
    var selectedTab by remember { mutableIntStateOf(0) }
    val tabs = listOf(
        strings.adminStats,
        strings.adminReports,
        strings.adminUsers,
        strings.adminCategories,
        strings.adminAnnouncements,
        strings.adminAppUpdate,
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(strings.adminDashboard) },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("admin_back_button")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = strings.back)
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(padding)
        ) {
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(tabs.indices.toList()) { idx ->
                    FilterChip(
                        selected = selectedTab == idx,
                        onClick = { selectedTab = idx },
                        label = { Text(tabs[idx]) }
                    )
                }
            }

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                when (selectedTab) {
                    0 -> {
                        val totalViews = videos.sumOf { it.viewsCount }
                        val pendingReports = reports.count { it.status == "PENDING" }
                        item {
                            StatCard(strings.adminStats, "${videos.size} Videos • ${formatCompactCount(totalViews)} ${strings.viewsLabel}")
                        }
                        item {
                            StatCard(strings.adminUsers, "${users.size} Users • ${users.count { it.banned }} Suspended")
                        }
                        item {
                            StatCard(strings.adminReports, "$pendingReports Pending / ${reports.size} Total")
                        }
                    }
                    1 -> {
                        items(reports, key = { it.id }) { rep ->
                            Card(
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                shape = RoundedCornerShape(16.dp)
                            ) {
                                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Text("${rep.videoTitle} (${rep.status})", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                                    Text(rep.reason, style = MaterialTheme.typography.bodyMedium)
                                    if (!rep.details.isNullOrBlank()) {
                                        Text(rep.details, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Button(
                                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                                            onClick = { onRemoveVideo(rep.videoId, rep.id) }
                                        ) { Text(strings.removeVideo) }
                                        OutlinedButton(onClick = { onDismissReport(rep.id) }) {
                                            Text(strings.dismissReport)
                                        }
                                    }
                                }
                            }
                        }
                    }
                    2 -> {
                        items(users, key = { it.userId }) { u ->
                            Card(
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                shape = RoundedCornerShape(16.dp)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(14.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(u.displayName, style = MaterialTheme.typography.titleSmall)
                                        Text("@${u.username} • ${if (u.banned) "Suspended" else "Active"}", style = MaterialTheme.typography.bodySmall)
                                    }
                                    Button(
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = if (u.banned) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.error
                                        ),
                                        onClick = { onSetUserBanned(u.userId, !u.banned) }
                                    ) {
                                        Text(if (u.banned) strings.unbanUser else strings.banUser)
                                    }
                                }
                            }
                        }
                    }
                    3 -> {
                        item {
                            var nameAr by remember { mutableStateOf("") }
                            var nameEn by remember { mutableStateOf("") }
                            var slug by remember { mutableStateOf("") }
                            Card(
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                shape = RoundedCornerShape(16.dp)
                            ) {
                                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedTextField(value = nameAr, onValueChange = { nameAr = it }, label = { Text("الاسم بالعربية") }, modifier = Modifier.fillMaxWidth())
                                    OutlinedTextField(value = nameEn, onValueChange = { nameEn = it }, label = { Text("English Name") }, modifier = Modifier.fillMaxWidth())
                                    OutlinedTextField(value = slug, onValueChange = { slug = it }, label = { Text("Slug (e.g. music)") }, modifier = Modifier.fillMaxWidth())
                                    Button(
                                        onClick = {
                                            onCreateCategory(nameAr, nameEn, slug, (categories.size + 1).toLong())
                                            nameAr = ""
                                            nameEn = ""
                                            slug = ""
                                        },
                                        modifier = Modifier.fillMaxWidth()
                                    ) { Text(strings.addCategory) }
                                }
                            }
                        }
                        items(categories, key = { it.slug }) { cat ->
                            StatCard("${cat.nameAr} / ${cat.nameEn}", "slug: ${cat.slug}")
                        }
                    }
                    4 -> {
                        item {
                            var title by remember { mutableStateOf("") }
                            var body by remember { mutableStateOf("") }
                            Card(
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                shape = RoundedCornerShape(16.dp)
                            ) {
                                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text(strings.videoTitleLabel) }, modifier = Modifier.fillMaxWidth())
                                    OutlinedTextField(value = body, onValueChange = { body = it }, label = { Text(strings.videoDescLabel) }, minLines = 3, modifier = Modifier.fillMaxWidth())
                                    Button(
                                        onClick = {
                                            if (title.isNotBlank() && body.isNotBlank()) {
                                                onBroadcastAnnouncement(title, body)
                                                title = ""
                                                body = ""
                                            }
                                        },
                                        modifier = Modifier.fillMaxWidth()
                                    ) { Text(strings.sendAnnouncement) }
                                }
                            }
                        }
                    }
                    5 -> {
                        item {
                            var versionCodeText by remember { mutableStateOf("2") }
                            var versionName by remember { mutableStateOf("1.1.0") }
                            var notesAr by remember { mutableStateOf("") }
                            var notesEn by remember { mutableStateOf("") }
                            var downloadUrl by remember { mutableStateOf("") }
                            var forceUpdate by remember { mutableStateOf(false) }

                            Card(
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                shape = RoundedCornerShape(16.dp)
                            ) {
                                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedTextField(value = versionCodeText, onValueChange = { versionCodeText = it }, label = { Text("Version Code (int)") }, modifier = Modifier.fillMaxWidth())
                                    OutlinedTextField(value = versionName, onValueChange = { versionName = it }, label = { Text("Version Name") }, modifier = Modifier.fillMaxWidth())
                                    OutlinedTextField(value = notesAr, onValueChange = { notesAr = it }, label = { Text("ملاحظات التحديث") }, modifier = Modifier.fillMaxWidth())
                                    OutlinedTextField(value = notesEn, onValueChange = { notesEn = it }, label = { Text("Release Notes (EN)") }, modifier = Modifier.fillMaxWidth())
                                    OutlinedTextField(value = downloadUrl, onValueChange = { downloadUrl = it }, label = { Text("Trusted APK Download URL (https://...)") }, modifier = Modifier.fillMaxWidth())
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text("Force Update")
                                        Switch(checked = forceUpdate, onCheckedChange = { forceUpdate = it })
                                    }
                                    Button(
                                        onClick = {
                                            val code = versionCodeText.toLongOrNull() ?: 2L
                                            if (downloadUrl.startsWith("https://")) {
                                                onPublishAppUpdate(code, versionName, notesAr, notesEn, downloadUrl, forceUpdate)
                                            }
                                        },
                                        modifier = Modifier.fillMaxWidth()
                                    ) { Text(strings.saveChanges) }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StatCard(title: String, value: String) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(4.dp))
            Text(value, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.primary)
        }
    }
}
