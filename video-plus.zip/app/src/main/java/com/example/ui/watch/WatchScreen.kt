package com.example.ui.watch

import android.app.Activity
import android.content.Intent
import android.content.pm.ActivityInfo
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.automirrored.filled.VolumeOff
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Forward10
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.FullscreenExit
import androidx.compose.material.icons.filled.HighQuality
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Replay10
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.ThumbDown
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import androidx.media3.ui.PlayerView
import com.example.model.VideoComment
import com.example.model.VideoItem
import com.example.model.VoteType
import com.example.ui.components.AvatarCircle
import com.example.ui.components.formatCompactCount
import com.example.ui.components.formatDuration
import com.example.ui.i18n.LocalAppStrings
import kotlinx.coroutines.delay

@androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
@Composable
fun WatchScreen(
    video: VideoItem?,
    currentUserId: String,
    userVote: VoteType?,
    isSaved: Boolean,
    isSubscribed: Boolean,
    comments: List<VideoComment>,
    upNextVideos: List<VideoItem>,
    onBack: () -> Unit,
    onRecordView: (VideoItem, Long) -> Unit,
    onVote: (String, VoteType) -> Unit,
    onToggleSave: (VideoItem, Boolean) -> Unit,
    onToggleSubscribe: (VideoItem, Boolean) -> Unit,
    onAddComment: (VideoItem, String, String?) -> Unit,
    onReportVideo: (VideoItem, String, String?) -> Unit,
    onBlockCreator: (String) -> Unit,
    onOpenNextVideo: (String) -> Unit,
    onOpenChannel: (String) -> Unit,
) {
    val strings = LocalAppStrings.current
    val context = LocalContext.current
    val activity = context as? Activity

    var isFullscreen by remember { mutableStateOf(false) }

    BackHandler {
        if (isFullscreen) {
            isFullscreen = false
            activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        } else {
            onBack()
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }

    if (video == null) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background),
            contentAlignment = Alignment.Center
        ) {
            CircularProgressIndicator()
        }
        return
    }

    val trackSelector = remember { DefaultTrackSelector(context) }
    val exoPlayer = remember(video.id) {
        ExoPlayer.Builder(context)
            .setTrackSelector(trackSelector)
            .build()
    }

    var isPlaying by remember { mutableStateOf(true) }
    var currentPosMs by remember { mutableLongStateOf(0L) }
    var durationMs by remember { mutableLongStateOf(0L) }
    var volumeLevel by remember { mutableFloatStateOf(1f) }
    var qualityOptions by remember { mutableStateOf<List<Pair<String, Int?>>>(listOf(strings.qualityAuto to null)) }
    var selectedQualityLabel by remember { mutableStateOf(strings.qualityAuto) }
    var showQualityMenu by remember { mutableStateOf(false) }
    var showReportDialog by remember { mutableStateOf(false) }
    var showBlockDialog by remember { mutableStateOf(false) }
    var commentInput by remember { mutableStateOf("") }
    var replyTarget by remember { mutableStateOf<VideoComment?>(null) }

    LaunchedEffect(video.id, video.videoUrl) {
        if (video.videoUrl.isNotBlank()) {
            exoPlayer.setMediaItem(MediaItem.fromUri(video.videoUrl))
            exoPlayer.prepare()
            exoPlayer.playWhenReady = true
            onRecordView(video, 0L)
        }
    }

    DisposableEffect(exoPlayer) {
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) {
                isPlaying = playing
            }

            override fun onTracksChanged(tracks: androidx.media3.common.Tracks) {
                val options = mutableListOf<Pair<String, Int?>>(strings.qualityAuto to null)
                tracks.groups.forEach { group ->
                    if (group.type == C.TRACK_TYPE_VIDEO) {
                        for (i in 0 until group.length) {
                            val format = group.getTrackFormat(i)
                            if (format.height > 0) {
                                options.add("${format.height}p" to format.height)
                            }
                        }
                    }
                }
                qualityOptions = options.distinctBy { it.first }
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_ENDED) {
                    upNextVideos.firstOrNull()?.let { next ->
                        onOpenNextVideo(next.id)
                    }
                }
            }
        }
        exoPlayer.addListener(listener)
        onDispose {
            val pos = exoPlayer.currentPosition
            if (pos > 1000L) {
                onRecordView(video, pos)
            }
            exoPlayer.removeListener(listener)
            exoPlayer.release()
        }
    }

    LaunchedEffect(exoPlayer, isPlaying) {
        while (true) {
            currentPosMs = exoPlayer.currentPosition.coerceAtLeast(0L)
            durationMs = exoPlayer.duration.coerceAtLeast(0L)
            delay(500L)
        }
    }

    val playerSurface: @Composable (Modifier) -> Unit = { mod ->
        Box(modifier = mod.background(Color.Black)) {
            AndroidView(
                factory = { ctx ->
                    PlayerView(ctx).apply {
                        useController = false
                        player = exoPlayer
                    }
                },
                update = { it.player = exoPlayer },
                modifier = Modifier.fillMaxSize()
            )

            // Custom Pro Controls Overlay
            Row(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .fillMaxWidth()
                    .padding(8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = {
                        if (isFullscreen) {
                            isFullscreen = false
                            activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                        } else {
                            onBack()
                        }
                    },
                    modifier = Modifier.testTag("watch_back_button")
                ) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = strings.back, tint = Color.White)
                }

                Box {
                    IconButton(
                        onClick = { showQualityMenu = true },
                        modifier = Modifier.testTag("watch_quality_button")
                    ) {
                        Icon(Icons.Default.HighQuality, contentDescription = strings.qualityLabel, tint = Color.White)
                    }
                    DropdownMenu(
                        expanded = showQualityMenu,
                        onDismissRequest = { showQualityMenu = false }
                    ) {
                        qualityOptions.forEach { (label, targetHeight) ->
                            DropdownMenuItem(
                                text = {
                                    Text(if (label == selectedQualityLabel) "✓ $label" else label)
                                },
                                onClick = {
                                    selectedQualityLabel = label
                                    showQualityMenu = false
                                    val paramsBuilder = trackSelector.buildUponParameters()
                                    if (targetHeight == null) {
                                        paramsBuilder.clearVideoSizeConstraints()
                                    } else {
                                        paramsBuilder.setMaxVideoSize(Int.MAX_VALUE, targetHeight)
                                    }
                                    trackSelector.setParameters(paramsBuilder)
                                }
                            )
                        }
                    }
                }
            }

            Row(
                modifier = Modifier.align(Alignment.Center),
                horizontalArrangement = Arrangement.spacedBy(20.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { exoPlayer.seekTo((exoPlayer.currentPosition - 10_000L).coerceAtLeast(0L)) },
                    modifier = Modifier.testTag("watch_rewind_button")
                ) {
                    Icon(Icons.Default.Replay10, contentDescription = "Rewind 10s", tint = Color.White, modifier = Modifier.size(34.dp))
                }
                IconButton(
                    onClick = {
                        if (exoPlayer.isPlaying) exoPlayer.pause() else exoPlayer.play()
                    },
                    modifier = Modifier
                        .size(56.dp)
                        .testTag("watch_play_pause_button")
                ) {
                    Icon(
                        imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                        contentDescription = if (isPlaying) "Pause" else "Play",
                        tint = Color.White,
                        modifier = Modifier.size(44.dp)
                    )
                }
                IconButton(
                    onClick = { exoPlayer.seekTo(exoPlayer.currentPosition + 10_000L) },
                    modifier = Modifier.testTag("watch_forward_button")
                ) {
                    Icon(Icons.Default.Forward10, contentDescription = "Forward 10s", tint = Color.White, modifier = Modifier.size(34.dp))
                }
                upNextVideos.firstOrNull()?.let { next ->
                    IconButton(
                        onClick = { onOpenNextVideo(next.id) },
                        modifier = Modifier.testTag("watch_next_button")
                    ) {
                        Icon(Icons.Default.SkipNext, contentDescription = strings.nextVideo, tint = Color.White, modifier = Modifier.size(34.dp))
                    }
                }
            }

            Column(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .background(Color(0x99000000))
                    .padding(horizontal = 12.dp, vertical = 4.dp)
            ) {
                val maxDur = durationMs.coerceAtLeast(1L).toFloat()
                Slider(
                    value = (currentPosMs.toFloat() / maxDur).coerceIn(0f, 1f),
                    onValueChange = { frac ->
                        exoPlayer.seekTo((frac * maxDur).toLong())
                    },
                    modifier = Modifier.fillMaxWidth()
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "${formatDuration(currentPosMs / 1000L)} / ${formatDuration((durationMs / 1000L).coerceAtLeast(video.durationSec))}",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.White
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(
                            onClick = {
                                volumeLevel = if (volumeLevel > 0f) 0f else 1f
                                exoPlayer.volume = volumeLevel
                            },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(
                                imageVector = if (volumeLevel > 0f) Icons.AutoMirrored.Filled.VolumeUp else Icons.AutoMirrored.Filled.VolumeOff,
                                contentDescription = strings.volumeLabel,
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Slider(
                            value = volumeLevel,
                            onValueChange = {
                                volumeLevel = it
                                exoPlayer.volume = it
                            },
                            modifier = Modifier.width(84.dp)
                        )
                        IconButton(
                            onClick = {
                                isFullscreen = !isFullscreen
                                activity?.requestedOrientation = if (isFullscreen) {
                                    ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                                } else {
                                    ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                                }
                            },
                            modifier = Modifier
                                .size(36.dp)
                                .testTag("watch_fullscreen_button")
                        ) {
                            Icon(
                                imageVector = if (isFullscreen) Icons.Default.FullscreenExit else Icons.Default.Fullscreen,
                                contentDescription = "Fullscreen",
                                tint = Color.White
                            )
                        }
                    }
                }
            }
        }
    }

    if (isFullscreen) {
        Box(modifier = Modifier.fillMaxSize()) {
            playerSurface(Modifier.fillMaxSize())
        }
        return
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        playerSurface(
            Modifier
                .fillMaxWidth()
                .aspectRatio(16f / 9f)
        )

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item(key = "video_header") {
                Column {
                    Text(
                        text = video.title,
                        style = MaterialTheme.typography.titleLarge,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "${formatCompactCount(video.viewsCount)} ${strings.viewsLabel} • ${video.category}" +
                            (if (!video.locationLabel.isNullOrBlank()) " • ${video.locationLabel}" else ""),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (video.description.isNotBlank()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = video.description,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }

            // Channel & Subscribe Row
            item(key = "channel_row") {
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        AvatarCircle(
                            name = video.authorName,
                            avatarUrl = video.authorAvatarUrl,
                            sizeDp = 44,
                            onClick = { onOpenChannel(video.authorId) }
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .clickable { onOpenChannel(video.authorId) }
                        ) {
                            Text(
                                text = video.authorName,
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                        if (video.authorId != currentUserId) {
                            Button(
                                onClick = { onToggleSubscribe(video, isSubscribed) },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isSubscribed) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.primary,
                                    contentColor = if (isSubscribed) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onPrimary
                                ),
                                modifier = Modifier.testTag("watch_subscribe_button")
                            ) {
                                Text(if (isSubscribed) strings.subscribed else strings.subscribe)
                            }
                        }
                    }
                }
            }

            // Social Interaction Bar (Like, Dislike, Save, Share, Report, Block)
            item(key = "social_actions") {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    item {
                        FilterChip(
                            selected = userVote == VoteType.LIKE,
                            onClick = { onVote(video.id, VoteType.LIKE) },
                            leadingIcon = { Icon(Icons.Default.ThumbUp, contentDescription = null, modifier = Modifier.size(18.dp)) },
                            label = { Text("${strings.like} (${formatCompactCount(video.likesCount)})") },
                            modifier = Modifier.testTag("watch_like_button")
                        )
                    }
                    item {
                        FilterChip(
                            selected = userVote == VoteType.DISLIKE,
                            onClick = { onVote(video.id, VoteType.DISLIKE) },
                            leadingIcon = { Icon(Icons.Default.ThumbDown, contentDescription = null, modifier = Modifier.size(18.dp)) },
                            label = { Text("${strings.dislike} (${formatCompactCount(video.dislikesCount)})") },
                            modifier = Modifier.testTag("watch_dislike_button")
                        )
                    }
                    item {
                        FilterChip(
                            selected = isSaved,
                            onClick = { onToggleSave(video, isSaved) },
                            leadingIcon = {
                                Icon(
                                    if (isSaved) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp)
                                )
                            },
                            label = { Text(if (isSaved) strings.saved else strings.save) },
                            modifier = Modifier.testTag("watch_save_button")
                        )
                    }
                    item {
                        FilterChip(
                            selected = false,
                            onClick = {
                                val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                    type = "text/plain"
                                    putExtra(Intent.EXTRA_SUBJECT, video.title)
                                    putExtra(Intent.EXTRA_TEXT, "${video.title}\n${video.videoUrl}")
                                }
                                context.startActivity(Intent.createChooser(shareIntent, strings.share))
                            },
                            leadingIcon = { Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(18.dp)) },
                            label = { Text(strings.share) },
                            modifier = Modifier.testTag("watch_share_button")
                        )
                    }
                    if (video.authorId != currentUserId) {
                        item {
                            FilterChip(
                                selected = false,
                                onClick = { showReportDialog = true },
                                leadingIcon = { Icon(Icons.Default.Flag, contentDescription = null, modifier = Modifier.size(18.dp)) },
                                label = { Text(strings.report) },
                                modifier = Modifier.testTag("watch_report_button")
                            )
                        }
                        item {
                            FilterChip(
                                selected = false,
                                onClick = { showBlockDialog = true },
                                leadingIcon = { Icon(Icons.Default.Block, contentDescription = null, modifier = Modifier.size(18.dp)) },
                                label = { Text(strings.blockCreator) },
                                modifier = Modifier.testTag("watch_block_button")
                            )
                        }
                    }
                }
            }

            // Up Next
            if (upNextVideos.isNotEmpty()) {
                item(key = "up_next_row") {
                    OutlinedButton(
                        onClick = { onOpenNextVideo(upNextVideos.first().id) },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.SkipNext, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("${strings.nextVideo}: ${upNextVideos.first().title}")
                    }
                }
            }

            // Comments Input & Header
            item(key = "comments_header") {
                Column {
                    HorizontalDivider()
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "${strings.commentsTitle} (${comments.size})",
                        style = MaterialTheme.typography.titleMedium
                    )
                    if (replyTarget != null) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(top = 6.dp)
                        ) {
                            Text(
                                text = "${strings.replyAction}: ${replyTarget?.authorName}",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.primary
                            )
                            TextButton(onClick = { replyTarget = null }) {
                                Text(strings.cancel)
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(
                            value = commentInput,
                            onValueChange = { commentInput = it },
                            placeholder = { Text(if (replyTarget != null) strings.replyHint else strings.addCommentHint) },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("watch_comment_input"),
                            shape = RoundedCornerShape(14.dp),
                            singleLine = true
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        IconButton(
                            onClick = {
                                if (commentInput.isNotBlank()) {
                                    onAddComment(video, commentInput, replyTarget?.id)
                                    commentInput = ""
                                    replyTarget = null
                                }
                            },
                            modifier = Modifier.testTag("watch_send_comment_button")
                        ) {
                            Icon(Icons.AutoMirrored.Filled.Send, contentDescription = strings.post)
                        }
                    }
                }
            }

            val topComments = comments.filter { it.parentCommentId.isNullOrBlank() }
            val repliesByParent = comments.filter { !it.parentCommentId.isNullOrBlank() }.groupBy { it.parentCommentId }

            items(topComments, key = { it.id }) { comment ->
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(14.dp))
                        .padding(12.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        AvatarCircle(comment.authorName, comment.authorAvatarUrl, sizeDp = 30)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(comment.authorName, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(comment.text, style = MaterialTheme.typography.bodyMedium)
                    TextButton(onClick = { replyTarget = comment }) {
                        Text(strings.replyAction, style = MaterialTheme.typography.labelMedium)
                    }
                    repliesByParent[comment.id].orEmpty().forEach { reply ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(start = 20.dp, top = 6.dp)
                                .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(10.dp))
                                .padding(8.dp)
                        ) {
                            Column {
                                Text(reply.authorName, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                                Text(reply.text, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            }
        }
    }

    if (showReportDialog) {
        var reason by remember { mutableStateOf("Spam or misleading") }
        var details by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showReportDialog = false },
            title = { Text(strings.report) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = reason, onValueChange = { reason = it }, label = { Text(strings.report) })
                    OutlinedTextField(value = details, onValueChange = { details = it }, label = { Text(strings.videoDescLabel) })
                }
            },
            confirmButton = {
                Button(onClick = {
                    onReportVideo(video, reason, details.ifBlank { null })
                    showReportDialog = false
                }) { Text(strings.confirm) }
            },
            dismissButton = {
                TextButton(onClick = { showReportDialog = false }) { Text(strings.cancel) }
            }
        )
    }

    if (showBlockDialog) {
        AlertDialog(
            onDismissRequest = { showBlockDialog = false },
            title = { Text(strings.blockCreator) },
            text = { Text(video.authorName) },
            confirmButton = {
                Button(onClick = {
                    onBlockCreator(video.authorId)
                    showBlockDialog = false
                    onBack()
                }) { Text(strings.confirm) }
            },
            dismissButton = {
                TextButton(onClick = { showBlockDialog = false }) { Text(strings.cancel) }
            }
        )
    }
}
