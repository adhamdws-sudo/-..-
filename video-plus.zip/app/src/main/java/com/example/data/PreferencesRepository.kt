package com.example.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.model.ThemeModePreference
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "video_plus_prefs")

data class UserPreferences(
    val languageCode: String = "ar",
    val themeMode: ThemeModePreference = ThemeModePreference.SYSTEM,
    val locationConsentGranted: Boolean = false,
)

class PreferencesRepository(private val context: Context) {

    private val keyLang = stringPreferencesKey("language_code")
    private val keyTheme = stringPreferencesKey("theme_mode")
    private val keyLocationConsent = booleanPreferencesKey("location_consent")

    val preferencesFlow: Flow<UserPreferences> = context.dataStore.data.map { prefs ->
        UserPreferences(
            languageCode = prefs[keyLang] ?: "ar",
            themeMode = ThemeModePreference.fromRaw(prefs[keyTheme]),
            locationConsentGranted = prefs[keyLocationConsent] ?: false,
        )
    }

    suspend fun setLanguage(code: String) {
        context.dataStore.edit { it[keyLang] = if (code == "en") "en" else "ar" }
    }

    suspend fun setThemeMode(mode: ThemeModePreference) {
        context.dataStore.edit { it[keyTheme] = mode.raw }
    }

    suspend fun setLocationConsent(granted: Boolean) {
        context.dataStore.edit { it[keyLocationConsent] = granted }
    }
}
