package com.example.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Log
import com.example.R
import com.example.model.AdminAnnouncement
import com.example.model.AppCloudConfig
import com.example.model.AppNotification
import com.example.model.NotificationType
import com.example.model.PrivateAccountInfo
import com.example.model.PublicProfile
import com.example.model.SavedVideoRef
import com.example.model.Subscription
import com.example.model.ThemeModePreference
import com.example.model.VideoCategory
import com.example.model.VideoComment
import com.example.model.VideoItem
import com.example.model.VideoPrivacy
import com.example.model.VideoReport
import com.example.model.VideoVote
import com.example.model.VoteType
import com.example.model.WatchHistoryItem
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.snapshots
import com.google.firebase.messaging.FirebaseMessaging
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.UploadTask
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.util.UUID

data class FeedPageResult(
    val videos: List<VideoItem>,
    val lastSnapshot: DocumentSnapshot?,
    val hasMore: Boolean,
)

data class UploadProgressState(
    val isUploading: Boolean = false,
    val progressFraction: Float = 0f,
    val publishedVideoId: String? = null,
    val errorMessage: String? = null,
)

class VideoPlusRepository(
    private val db: FirebaseFirestore,
    private val storage: FirebaseStorage = FirebaseStorage.getInstance(),
    private val auth: FirebaseAuth = Firebase.auth,
) {
    constructor(context: Context) : this(
        db = FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in with Google before accessing Firestore.")
    }

    private fun <T> safeSnapshotFlow(
        path: String,
        upstream: Flow<T>,
    ): Flow<T> = flow {
        val uid = requireUserId()
        emitAll(
            upstream.catch { error ->
                val firestoreError = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (firestoreError == null && error is CancellationException) throw error
                val ex = firestoreError ?: (error as? Exception)
                if (ex != null && auth.currentUser?.uid == uid) {
                    handleFirestoreError(ex, OperationType.LIST, path)
                }
                throw error
            }
        )
    }

    // --- User Bootstrap & Profile ---

    suspend fun ensureUserProfileInitialized(): Result<Unit> {
        val user = auth.currentUser ?: return Result.failure(IllegalStateException("Not signed in"))
        val uid = user.uid
        return try {
            val publicRef = db.collection("users").document(uid)
            val publicSnap = publicRef.get().await()
            if (!publicSnap.exists()) {
                val safeDisplayName = (user.displayName?.takeIf { it.isNotBlank() } ?: "Video Plus User").take(80)
                val safeUsername = (user.email?.substringBefore("@") ?: "user_${uid.take(6)}")
                    .replace(Regex("[^a-zA-Z0-9_\\-]"), "_")
                    .take(36)
                    .ifBlank { "creator_${uid.take(6)}" }
                val publicPayload = mapOf(
                    "userId" to uid,
                    "displayName" to safeDisplayName,
                    "username" to safeUsername,
                    "bio" to "",
                    "avatarUrl" to user.photoUrl?.toString()?.take(900),
                    "subscribersCount" to 0L,
                    "videosCount" to 0L,
                    "banned" to false,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp(),
                ).filterValues { it != null }
                publicRef.set(publicPayload).await()
            }

            val privateRef = publicRef.collection("private").document("info")
            val privateSnap = privateRef.get().await()
            if (!privateSnap.exists()) {
                val privatePayload = mapOf(
                    "userId" to uid,
                    "email" to (user.email ?: "").take(200),
                    "languageCode" to "ar",
                    "themeMode" to ThemeModePreference.SYSTEM.raw,
                    "locationConsent" to false,
                    "blockedUserIds" to emptyList<String>(),
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp(),
                )
                privateRef.set(privatePayload).await()
            }

            // Best-effort FCM token sync
            try {
                val token = FirebaseMessaging.getInstance().token.await()
                if (!token.isNullOrBlank()) {
                    privateRef.update(
                        mapOf(
                            "fcmToken" to token.take(500),
                            "updatedAt" to FieldValue.serverTimestamp(),
                        )
                    ).await()
                }
            } catch (e: Exception) {
                Log.w(TAG, "FCM token sync skipped: ${e.message}")
            }

            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, "users/$uid")
            Result.failure(e)
        }
    }

    fun observePublicProfile(userId: String): Flow<PublicProfile?> =
        safeSnapshotFlow(
            path = "users/$userId",
            upstream = db.collection("users").document(userId)
                .snapshots()
                .map { snap -> snap.toObject(PublicProfile::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }
        )

    fun observePrivateAccount(userId: String): Flow<PrivateAccountInfo?> =
        safeSnapshotFlow(
            path = "users/$userId/private/info",
            upstream = db.collection("users").document(userId)
                .collection("private").document("info")
                .snapshots()
                .map { snap -> snap.toObject(PrivateAccountInfo::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }
        )

    suspend fun updateProfile(displayName: String, username: String, bio: String): Result<Unit> {
        val uid = auth.currentUser?.uid ?: return Result.failure(IllegalStateException("Not signed in"))
        val cleanDisplay = displayName.trim().take(80)
        val cleanUsername = username.trim().take(40)
        val cleanBio = bio.trim().take(300)
        if (cleanDisplay.isEmpty() || cleanUsername.length < 2) {
            return Result.failure(IllegalArgumentException("Display name or username invalid"))
        }
        return try {
            db.collection("users").document(uid)
                .update(
                    mapOf(
                        "displayName" to cleanDisplay,
                        "username" to cleanUsername,
                        "bio" to cleanBio,
                        "updatedAt" to FieldValue.serverTimestamp(),
                    )
                ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, "users/$uid")
            Result.failure(e)
        }
    }

    suspend fun syncAccountPreferences(languageCode: String, themeMode: ThemeModePreference, locationConsent: Boolean): Result<Unit> {
        val uid = auth.currentUser?.uid ?: return Result.failure(IllegalStateException("Not signed in"))
        return try {
            db.collection("users").document(uid).collection("private").document("info")
                .update(
                    mapOf(
                        "languageCode" to if (languageCode == "en") "en" else "ar",
                        "themeMode" to themeMode.raw,
                        "locationConsent" to locationConsent,
                        "updatedAt" to FieldValue.serverTimestamp(),
                    )
                ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, "users/$uid/private/info")
            Result.failure(e)
        }
    }

    suspend fun checkIsAdmin(): Boolean {
        val user = auth.currentUser ?: return false
        if (user.email.equals(BOOTSTRAP_ADMIN_EMAIL, ignoreCase = true) && user.isEmailVerified) {
            return true
        }
        return try {
            val snap = db.collection("admins").document(user.uid).get().await()
            snap.exists()
        } catch (_: Exception) {
            false
        }
    }

    suspend fun deleteAccountAndData(): Result<Unit> {
        val user = auth.currentUser ?: return Result.failure(IllegalStateException("Not signed in"))
        val uid = user.uid
        return try {
            val userDoc = db.collection("users").document(uid)
            val subCollections = listOf("private", "saved", "history", "subscriptions", "notifications")
            for (sub in subCollections) {
                val docs = userDoc.collection(sub).get().await()
                for (doc in docs.documents) {
                    doc.reference.delete().await()
                }
            }
            userDoc.delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, "users/$uid")
            Result.failure(e)
        }
    }

    // --- Video Feed, Pagination & Search ---

    fun observePublicVideos(limit: Long = 30L): Flow<List<VideoItem>> =
        safeSnapshotFlow(
            path = "videos",
            upstream = db.collection("videos")
                .whereEqualTo("privacy", VideoPrivacy.PUBLIC.raw)
                .whereEqualTo("status", "ACTIVE")
                .limit(limit)
                .snapshots()
                .map { snap ->
                    snap.toObjects(VideoItem::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.createdAt?.seconds ?: 0L }
                }
        )

    suspend fun fetchPublicVideosPage(lastSnapshot: DocumentSnapshot?, pageSize: Long = 15L): Result<FeedPageResult> {
        return try {
            requireUserId()
            var query = db.collection("videos")
                .whereEqualTo("privacy", VideoPrivacy.PUBLIC.raw)
                .whereEqualTo("status", "ACTIVE")
                .limit(pageSize)
            if (lastSnapshot != null) {
                query = query.startAfter(lastSnapshot)
            }
            val snap = query.get().await()
            val items = snap.toObjects(VideoItem::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
            Result.success(
                FeedPageResult(
                    videos = items,
                    lastSnapshot = snap.documents.lastOrNull(),
                    hasMore = snap.size() >= pageSize,
                )
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.LIST, "videos")
            Result.failure(e)
        }
    }

    fun observeMyVideos(userId: String): Flow<List<VideoItem>> =
        safeSnapshotFlow(
            path = "videos",
            upstream = db.collection("videos")
                .whereEqualTo("authorId", userId)
                .snapshots()
                .map { snap ->
                    snap.toObjects(VideoItem::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .filter { it.status == "ACTIVE" }
                        .sortedByDescending { it.createdAt?.seconds ?: 0L }
                }
        )

    fun observeVideo(videoId: String): Flow<VideoItem?> =
        safeSnapshotFlow(
            path = "videos/$videoId",
            upstream = db.collection("videos").document(videoId)
                .snapshots()
                .map { snap -> snap.toObject(VideoItem::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }
        )

    // --- Resumable Upload (Firebase Storage + Firestore) ---

    suspend fun uploadAndPublishVideo(
        context: Context,
        videoUri: Uri,
        thumbnailUri: Uri?,
        title: String,
        description: String,
        category: String,
        privacy: VideoPrivacy,
        shortVideo: Boolean,
        durationSec: Long,
        locationLabel: String?,
        onProgress: (Float) -> Unit,
        onTaskCreated: (UploadTask) -> Unit,
    ): Result<String> {
        val user = auth.currentUser ?: return Result.failure(IllegalStateException("Not signed in"))
        val uid = user.uid
        val videoId = "vid_${UUID.randomUUID().toString().replace("-", "").take(20)}"
        return try {
            val profile = db.collection("users").document(uid).get().await()
                .toObject(PublicProfile::class.java)
            if (profile?.banned == true) {
                return Result.failure(IllegalStateException("Account is suspended"))
            }

            // 1. Compress & upload thumbnail if provided
            var thumbnailDownloadUrl = ""
            if (thumbnailUri != null) {
                val compressedBytes = compressThumbnail(context, thumbnailUri)
                if (compressedBytes != null) {
                    val thumbRef = storage.reference.child("thumbnails/$uid/$videoId.jpg")
                    thumbRef.putBytes(compressedBytes).await()
                    thumbnailDownloadUrl = thumbRef.downloadUrl.await().toString()
                }
            }

            // 2. Resumable upload for video file
            val videoRef = storage.reference.child("videos/$uid/$videoId.mp4")
            val uploadTask = videoRef.putFile(videoUri)
            onTaskCreated(uploadTask)
            uploadTask.addOnProgressListener { snap ->
                val total = snap.totalByteCount.coerceAtLeast(1L)
                onProgress((snap.bytesTransferred.toFloat() / total.toFloat()).coerceIn(0f, 1f))
            }
            uploadTask.await()
            val videoDownloadUrl = videoRef.downloadUrl.await().toString()

            // 3. Create Firestore document matching rules 1:1
            val authorName = (profile?.displayName?.takeIf { it.isNotBlank() }
                ?: user.displayName?.takeIf { it.isNotBlank() }
                ?: "Creator").take(80)
            val payload = mapOf(
                "authorId" to uid,
                "authorName" to authorName,
                "authorAvatarUrl" to (profile?.avatarUrl ?: user.photoUrl?.toString())?.take(900),
                "title" to title.trim().take(160),
                "description" to description.trim().take(2000),
                "category" to category.ifBlank { "general" }.take(60),
                "videoUrl" to videoDownloadUrl.take(1200),
                "thumbnailUrl" to thumbnailDownloadUrl.take(1200),
                "privacy" to privacy.raw,
                "shortVideo" to shortVideo,
                "durationSec" to durationSec.coerceIn(0L, 86400L),
                "viewsCount" to 0L,
                "likesCount" to 0L,
                "dislikesCount" to 0L,
                "commentsCount" to 0L,
                "locationLabel" to locationLabel?.trim()?.take(120)?.takeIf { it.isNotEmpty() },
                "qualityLabels" to listOf("Auto", "720p", "480p"),
                "status" to "ACTIVE",
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp(),
            ).filterValues { it != null }

            db.collection("videos").document(videoId).set(payload).await()
            db.collection("users").document(uid).update(
                mapOf(
                    "videosCount" to FieldValue.increment(1L),
                    "updatedAt" to FieldValue.serverTimestamp(),
                )
            ).await()

            Result.success(videoId)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, "videos/$videoId")
            Result.failure(e)
        }
    }

    private suspend fun compressThumbnail(context: Context, uri: Uri): ByteArray? = withContext(Dispatchers.IO) {
        try {
            val stream = context.contentResolver.openInputStream(uri) ?: return@withContext null
            val bitmap = stream.use { BitmapFactory.decodeStream(it) } ?: return@withContext null
            val maxDim = 960
            val scale = minOf(maxDim.toFloat() / bitmap.width, maxDim.toFloat() / bitmap.height, 1f)
            val scaled = if (scale < 1f) {
                Bitmap.createScaledBitmap(
                    bitmap,
                    (bitmap.width * scale).toInt().coerceAtLeast(1),
                    (bitmap.height * scale).toInt().coerceAtLeast(1),
                    true
                )
            } else {
                bitmap
            }
            val out = ByteArrayOutputStream()
            scaled.compress(Bitmap.CompressFormat.JPEG, 78, out)
            if (scaled !== bitmap) scaled.recycle()
            bitmap.recycle()
            out.toByteArray()
        } catch (e: Exception) {
            Log.w(TAG, "Thumbnail compression failed: ${e.message}")
            null
        }
    }

    // --- Player Views, History & Social Interactions ---

    suspend fun recordViewAndHistory(video: VideoItem, positionMs: Long = 0L): Result<Unit> {
        val uid = auth.currentUser?.uid ?: return Result.failure(IllegalStateException("Not signed in"))
        return try {
            db.collection("videos").document(video.id)
                .update(
                    mapOf(
                        "viewsCount" to FieldValue.increment(1L),
                        "updatedAt" to FieldValue.serverTimestamp(),
                    )
                ).await()

            val histRef = db.collection("users").document(uid).collection("history").document(video.id)
            val existing = histRef.get().await()
            if (existing.exists()) {
                histRef.update(
                    mapOf(
                        "title" to video.title.take(160),
                        "thumbnailUrl" to video.thumbnailUrl.take(900),
                        "authorName" to video.authorName.take(80),
                        "durationSec" to video.durationSec.coerceIn(0L, 86400L),
                        "watchedPositionMs" to positionMs.coerceAtLeast(0L),
                        "updatedAt" to FieldValue.serverTimestamp(),
                    )
                ).await()
            } else {
                histRef.set(
                    mapOf(
                        "userId" to uid,
                        "videoId" to video.id,
                        "title" to video.title.take(160),
                        "thumbnailUrl" to video.thumbnailUrl.take(900),
                        "authorName" to video.authorName.take(80),
                        "durationSec" to video.durationSec.coerceIn(0L, 86400L),
                        "watchedPositionMs" to positionMs.coerceAtLeast(0L),
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp(),
                    )
                ).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, "videos/${video.id}")
            Result.failure(e)
        }
    }

    fun observeUserVote(videoId: String, userId: String): Flow<VoteType?> =
        safeSnapshotFlow(
            path = "videos/$videoId/votes/$userId",
            upstream = db.collection("videos").document(videoId)
                .collection("votes").document(userId)
                .snapshots()
                .map { snap ->
                    if (!snap.exists()) null
                    else VoteType.fromRaw(snap.getString("voteType"))
                }
        )

    suspend fun toggleVote(videoId: String, targetVote: VoteType): Result<Unit> {
        val uid = auth.currentUser?.uid ?: return Result.failure(IllegalStateException("Not signed in"))
        val videoRef = db.collection("videos").document(videoId)
        val voteRef = videoRef.collection("votes").document(uid)
        return try {
            db.runTransaction { tx ->
                val videoSnap = tx.get(videoRef)
                val voteSnap = tx.get(voteRef)
                val currentLikes = (videoSnap.getLong("likesCount") ?: 0L).coerceAtLeast(0L)
                val currentDislikes = (videoSnap.getLong("dislikesCount") ?: 0L).coerceAtLeast(0L)
                val existingType = if (voteSnap.exists()) VoteType.fromRaw(voteSnap.getString("voteType")) else null

                var likeDelta = 0L
                var dislikeDelta = 0L

                when {
                    existingType == targetVote -> {
                        tx.delete(voteRef)
                        if (targetVote == VoteType.LIKE) likeDelta = -1L else dislikeDelta = -1L
                    }
                    existingType == null -> {
                        tx.set(
                            voteRef,
                            mapOf(
                                "userId" to uid,
                                "videoId" to videoId,
                                "voteType" to targetVote.raw,
                                "createdAt" to FieldValue.serverTimestamp(),
                                "updatedAt" to FieldValue.serverTimestamp(),
                            )
                        )
                        if (targetVote == VoteType.LIKE) likeDelta = 1L else dislikeDelta = 1L
                    }
                    else -> {
                        tx.update(
                            voteRef,
                            mapOf(
                                "voteType" to targetVote.raw,
                                "updatedAt" to FieldValue.serverTimestamp(),
                            )
                        )
                        if (targetVote == VoteType.LIKE) {
                            likeDelta = 1L
                            dislikeDelta = -1L
                        } else {
                            likeDelta = -1L
                            dislikeDelta = 1L
                        }
                    }
                }

                tx.update(
                    videoRef,
                    mapOf(
                        "likesCount" to (currentLikes + likeDelta).coerceAtLeast(0L),
                        "dislikesCount" to (currentDislikes + dislikeDelta).coerceAtLeast(0L),
                        "updatedAt" to FieldValue.serverTimestamp(),
                    )
                )
            }.await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, "videos/$videoId/votes/$uid")
            Result.failure(e)
        }
    }

    fun observeComments(videoId: String): Flow<List<VideoComment>> =
        safeSnapshotFlow(
            path = "videos/$videoId/comments",
            upstream = db.collection("videos").document(videoId)
                .collection("comments")
                .snapshots()
                .map { snap ->
                    snap.toObjects(VideoComment::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.createdAt?.seconds ?: 0L }
                }
        )

    suspend fun addComment(
        video: VideoItem,
        text: String,
        parentCommentId: String? = null,
    ): Result<Unit> {
        val user = auth.currentUser ?: return Result.failure(IllegalStateException("Not signed in"))
        val uid = user.uid
        val cleanText = text.trim().take(1000)
        if (cleanText.isEmpty()) return Result.failure(IllegalArgumentException("Empty comment"))
        val commentId = "cmt_${UUID.randomUUID().toString().replace("-", "").take(16)}"
        return try {
            val profile = db.collection("users").document(uid).get().await().toObject(PublicProfile::class.java)
            val authorName = (profile?.displayName?.takeIf { it.isNotBlank() } ?: user.displayName ?: "User").take(80)
            val payload = mapOf(
                "videoId" to video.id,
                "authorId" to uid,
                "authorName" to authorName,
                "authorAvatarUrl" to (profile?.avatarUrl ?: user.photoUrl?.toString())?.take(900),
                "text" to cleanText,
                "parentCommentId" to parentCommentId?.take(128),
                "likesCount" to 0L,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp(),
            ).filterValues { it != null }

            db.collection("videos").document(video.id).collection("comments").document(commentId)
                .set(payload).await()
            db.collection("videos").document(video.id)
                .update(
                    mapOf(
                        "commentsCount" to FieldValue.increment(1L),
                        "updatedAt" to FieldValue.serverTimestamp(),
                    )
                ).await()

            if (video.authorId != uid) {
                sendInboxNotification(
                    targetUserId = video.authorId,
                    title = authorName,
                    body = cleanText.take(160),
                    type = NotificationType.COMMENT,
                    targetVideoId = video.id
                )
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, "videos/${video.id}/comments/$commentId")
            Result.failure(e)
        }
    }

    suspend fun toggleSaveVideo(video: VideoItem, currentlySaved: Boolean): Result<Unit> {
        val uid = auth.currentUser?.uid ?: return Result.failure(IllegalStateException("Not signed in"))
        val ref = db.collection("users").document(uid).collection("saved").document(video.id)
        return try {
            if (currentlySaved) {
                ref.delete().await()
            } else {
                val payload = mapOf(
                    "userId" to uid,
                    "videoId" to video.id,
                    "title" to video.title.take(160),
                    "thumbnailUrl" to video.thumbnailUrl.take(900),
                    "authorName" to video.authorName.take(80),
                    "durationSec" to video.durationSec.coerceIn(0L, 86400L),
                    "shortVideo" to video.shortVideo,
                    "createdAt" to FieldValue.serverTimestamp(),
                )
                ref.set(payload).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, "users/$uid/saved/${video.id}")
            Result.failure(e)
        }
    }

    fun observeSavedVideos(userId: String): Flow<List<SavedVideoRef>> =
        safeSnapshotFlow(
            path = "users/$userId/saved",
            upstream = db.collection("users").document(userId).collection("saved")
                .snapshots()
                .map { snap ->
                    snap.toObjects(SavedVideoRef::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.createdAt?.seconds ?: 0L }
                }
        )

    fun observeWatchHistory(userId: String): Flow<List<WatchHistoryItem>> =
        safeSnapshotFlow(
            path = "users/$userId/history",
            upstream = db.collection("users").document(userId).collection("history")
                .snapshots()
                .map { snap ->
                    snap.toObjects(WatchHistoryItem::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.updatedAt?.seconds ?: 0L }
                }
        )

    fun observeSubscriptions(userId: String): Flow<List<Subscription>> =
        safeSnapshotFlow(
            path = "users/$userId/subscriptions",
            upstream = db.collection("users").document(userId).collection("subscriptions")
                .snapshots()
                .map { snap ->
                    snap.toObjects(Subscription::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.createdAt?.seconds ?: 0L }
                }
        )

    suspend fun toggleSubscription(
        channelId: String,
        channelName: String,
        channelAvatarUrl: String?,
        currentlySubscribed: Boolean,
    ): Result<Unit> {
        val uid = auth.currentUser?.uid ?: return Result.failure(IllegalStateException("Not signed in"))
        if (channelId == uid) return Result.failure(IllegalArgumentException("Cannot subscribe to own channel"))
        val subRef = db.collection("users").document(uid).collection("subscriptions").document(channelId)
        val channelRef = db.collection("users").document(channelId)
        return try {
            if (currentlySubscribed) {
                subRef.delete().await()
                val chSnap = channelRef.get().await()
                if (chSnap.exists() && (chSnap.getLong("subscribersCount") ?: 0L) > 0L) {
                    channelRef.update(
                        mapOf(
                            "subscribersCount" to FieldValue.increment(-1L),
                            "updatedAt" to FieldValue.serverTimestamp(),
                        )
                    ).await()
                }
            } else {
                val payload = mapOf(
                    "userId" to uid,
                    "channelId" to channelId,
                    "channelName" to channelName.take(80),
                    "channelAvatarUrl" to channelAvatarUrl?.take(900),
                    "createdAt" to FieldValue.serverTimestamp(),
                ).filterValues { it != null }
                subRef.set(payload).await()
                if (channelRef.get().await().exists()) {
                    channelRef.update(
                        mapOf(
                            "subscribersCount" to FieldValue.increment(1L),
                            "updatedAt" to FieldValue.serverTimestamp(),
                        )
                    ).await()
                }
                val myName = auth.currentUser?.displayName ?: "Creator"
                sendInboxNotification(
                    targetUserId = channelId,
                    title = myName,
                    body = "Subscribed to your channel",
                    type = NotificationType.SUBSCRIPTION,
                    targetVideoId = null
                )
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, "users/$uid/subscriptions/$channelId")
            Result.failure(e)
        }
    }

    suspend fun toggleBlockUser(targetUserId: String, block: Boolean): Result<Unit> {
        val uid = auth.currentUser?.uid ?: return Result.failure(IllegalStateException("Not signed in"))
        if (targetUserId == uid) return Result.failure(IllegalArgumentException("Cannot block yourself"))
        val ref = db.collection("users").document(uid).collection("private").document("info")
        return try {
            val op = if (block) FieldValue.arrayUnion(targetUserId) else FieldValue.arrayRemove(targetUserId)
            ref.update(
                mapOf(
                    "blockedUserIds" to op,
                    "updatedAt" to FieldValue.serverTimestamp(),
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, "users/$uid/private/info")
            Result.failure(e)
        }
    }

    suspend fun reportVideo(video: VideoItem, reason: String, details: String?): Result<Unit> {
        val uid = auth.currentUser?.uid ?: return Result.failure(IllegalStateException("Not signed in"))
        val reportId = "rep_${UUID.randomUUID().toString().replace("-", "").take(16)}"
        return try {
            val payload = mapOf(
                "reporterId" to uid,
                "videoId" to video.id,
                "videoTitle" to video.title.take(160),
                "targetUserId" to video.authorId,
                "reason" to reason.trim().take(120).ifBlank { "Inappropriate content" },
                "details" to details?.trim()?.take(500)?.takeIf { it.isNotEmpty() },
                "status" to "PENDING",
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp(),
            ).filterValues { it != null }
            db.collection("reports").document(reportId).set(payload).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, "reports/$reportId")
            Result.failure(e)
        }
    }

    // --- Notifications ---

    fun observeNotifications(userId: String): Flow<List<AppNotification>> =
        safeSnapshotFlow(
            path = "users/$userId/notifications",
            upstream = db.collection("users").document(userId).collection("notifications")
                .snapshots()
                .map { snap ->
                    snap.toObjects(AppNotification::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.createdAt?.seconds ?: 0L }
                }
        )

    suspend fun markNotificationRead(notificationId: String): Result<Unit> {
        val uid = auth.currentUser?.uid ?: return Result.failure(IllegalStateException("Not signed in"))
        return try {
            db.collection("users").document(uid)
                .collection("notifications").document(notificationId)
                .update("readFlag", true).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, "users/$uid/notifications/$notificationId")
            Result.failure(e)
        }
    }

    private suspend fun sendInboxNotification(
        targetUserId: String,
        title: String,
        body: String,
        type: NotificationType,
        targetVideoId: String?,
    ) {
        val notifId = "ntf_${UUID.randomUUID().toString().replace("-", "").take(16)}"
        val payload = mapOf(
            "userId" to targetUserId,
            "title" to title.take(120),
            "body" to body.take(500),
            "type" to type.raw,
            "targetVideoId" to targetVideoId?.take(128),
            "readFlag" to false,
            "createdAt" to FieldValue.serverTimestamp(),
        ).filterValues { it != null }
        try {
            db.collection("users").document(targetUserId)
                .collection("notifications").document(notifId)
                .set(payload).await()
        } catch (e: Exception) {
            Log.w(TAG, "Inbox notification skipped: ${e.message}")
        }
    }

    // --- Cloud Categories, Announcements & App Update Config ---

    fun observeCategories(): Flow<List<VideoCategory>> =
        safeSnapshotFlow(
            path = "categories",
            upstream = db.collection("categories")
                .whereEqualTo("active", true)
                .snapshots()
                .map { snap ->
                    snap.toObjects(VideoCategory::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedBy { it.sortOrder }
                }
        )

    fun observeAnnouncements(): Flow<List<AdminAnnouncement>> =
        safeSnapshotFlow(
            path = "announcements",
            upstream = db.collection("announcements")
                .whereEqualTo("active", true)
                .snapshots()
                .map { snap ->
                    snap.toObjects(AdminAnnouncement::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.createdAt?.seconds ?: 0L }
                }
        )

    fun observeCloudConfig(): Flow<AppCloudConfig?> =
        safeSnapshotFlow(
            path = "app_config/latest",
            upstream = db.collection("app_config").document("latest")
                .snapshots()
                .map { snap -> snap.toObject(AppCloudConfig::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }
        )

    // --- Admin Operations (Server-enforced via Firestore Rules) ---

    fun observeAllReportsForAdmin(): Flow<List<VideoReport>> =
        safeSnapshotFlow(
            path = "reports",
            upstream = db.collection("reports")
                .snapshots()
                .map { snap ->
                    snap.toObjects(VideoReport::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.createdAt?.seconds ?: 0L }
                }
        )

    fun observeAllUsersForAdmin(): Flow<List<PublicProfile>> =
        safeSnapshotFlow(
            path = "users",
            upstream = db.collection("users")
                .snapshots()
                .map { snap ->
                    snap.toObjects(PublicProfile::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.subscribersCount }
                }
        )

    suspend fun adminRemoveVideo(videoId: String, reportId: String? = null): Result<Unit> {
        return try {
            requireUserId()
            db.collection("videos").document(videoId)
                .update(
                    mapOf(
                        "status" to "REMOVED",
                        "updatedAt" to FieldValue.serverTimestamp(),
                    )
                ).await()
            if (!reportId.isNullOrBlank()) {
                db.collection("reports").document(reportId)
                    .update(
                        mapOf(
                            "status" to "REVIEWED",
                            "updatedAt" to FieldValue.serverTimestamp(),
                        )
                    ).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, "videos/$videoId")
            Result.failure(e)
        }
    }

    suspend fun adminDismissReport(reportId: String): Result<Unit> {
        return try {
            requireUserId()
            db.collection("reports").document(reportId)
                .update(
                    mapOf(
                        "status" to "DISMISSED",
                        "updatedAt" to FieldValue.serverTimestamp(),
                    )
                ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, "reports/$reportId")
            Result.failure(e)
        }
    }

    suspend fun adminSetUserBanned(targetUserId: String, banned: Boolean): Result<Unit> {
        return try {
            requireUserId()
            db.collection("users").document(targetUserId)
                .update(
                    mapOf(
                        "banned" to banned,
                        "updatedAt" to FieldValue.serverTimestamp(),
                    )
                ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, "users/$targetUserId")
            Result.failure(e)
        }
    }

    suspend fun adminCreateCategory(nameAr: String, nameEn: String, slug: String, sortOrder: Long): Result<Unit> {
        val cleanSlug = slug.trim().lowercase().replace(Regex("[^a-z0-9_\\-]"), "_").take(60)
        if (cleanSlug.isEmpty()) return Result.failure(IllegalArgumentException("Invalid slug"))
        return try {
            requireUserId()
            db.collection("categories").document(cleanSlug)
                .set(
                    mapOf(
                        "nameAr" to nameAr.trim().take(60),
                        "nameEn" to nameEn.trim().take(60),
                        "slug" to cleanSlug,
                        "sortOrder" to sortOrder.coerceIn(0L, 1000L),
                        "active" to true,
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp(),
                    )
                ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, "categories/$cleanSlug")
            Result.failure(e)
        }
    }

    suspend fun adminBroadcastAnnouncement(title: String, message: String): Result<Unit> {
        val uid = auth.currentUser?.uid ?: return Result.failure(IllegalStateException("Not signed in"))
        val annId = "ann_${UUID.randomUUID().toString().replace("-", "").take(16)}"
        return try {
            db.collection("announcements").document(annId)
                .set(
                    mapOf(
                        "authorId" to uid,
                        "title" to title.trim().take(120),
                        "message" to message.trim().take(1000),
                        "active" to true,
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp(),
                    )
                ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, "announcements/$annId")
            Result.failure(e)
        }
    }

    suspend fun adminPublishAppUpdate(
        latestVersionCode: Long,
        latestVersionName: String,
        notesAr: String,
        notesEn: String,
        downloadUrl: String,
        forceUpdate: Boolean,
    ): Result<Unit> {
        return try {
            requireUserId()
            db.collection("app_config").document("latest")
                .set(
                    mapOf(
                        "latestVersionCode" to latestVersionCode.coerceAtLeast(1L),
                        "latestVersionName" to latestVersionName.trim().take(30),
                        "updateNotesAr" to notesAr.trim().take(500),
                        "updateNotesEn" to notesEn.trim().take(500),
                        "downloadUrl" to downloadUrl.trim().take(1000),
                        "forceUpdate" to forceUpdate,
                        "updatedAt" to FieldValue.serverTimestamp(),
                    )
                ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, "app_config/latest")
            Result.failure(e)
        }
    }

    companion object {
        private const val TAG = "VideoPlusRepo"
        private const val BOOTSTRAP_ADMIN_EMAIL = "adhamdws@gmail.com"
    }
}
