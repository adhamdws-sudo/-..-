package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.example.fcm.VideoPlusMessagingService
import com.example.ui.VideoPlusAppRoot

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val videoIdFromNotification = intent?.getStringExtra(VideoPlusMessagingService.EXTRA_VIDEO_ID)
        setContent {
            VideoPlusAppRoot(initialVideoIdFromIntent = videoIdFromNotification)
        }
    }
}
